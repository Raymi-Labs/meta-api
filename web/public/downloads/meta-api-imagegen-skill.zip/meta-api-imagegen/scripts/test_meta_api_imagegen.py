"""Offline checks: fake credentials, mocked HTTP, and bounded child-process tests."""
import base64
from contextlib import redirect_stdout
import io
import json
import os
from pathlib import Path
import socket
import ssl
import subprocess
import sys
import tempfile
import time
import unittest
import warnings
from unittest.mock import patch
import urllib.error
import urllib.request
import urllib.parse

import meta_api_imagegen as m

PNG = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII="
)
RESULT = {"data": [{"b64_json": base64.b64encode(PNG).decode()}]}
KEY = "test-only-credential"
SYSTEM_ENV = {k: os.environ[k] for k in ("SystemRoot", "WINDIR", "COMSPEC") if k in os.environ}


class Response(io.BytesIO):
    status = 200


class Tests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory(prefix="meta-imagegen-test-")
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.out = self.root / "output.png"
        for p in [
            patch.object(m, "LOCAL_CREDENTIAL_FILE", self.root / "config" / "credentials.json"),
            patch.dict(os.environ, dict(SYSTEM_ENV, META_API_KEY=KEY), clear=True),
            patch("socket.socket", side_effect=AssertionError("Unexpected real network call")),
        ]:
            p.start()
            self.addCleanup(p.stop)
        self.preflight = patch.object(m, "check_network", return_value=401)
        self.check = self.preflight.start()
        self.addCleanup(self.preflight.stop)

    def call(self, args=()):
        output = io.StringIO()
        with redirect_stdout(output):
            code = m.main(["--prompt", "A blue circle", "--out", str(self.out), *args])
        return code, output.getvalue()

    def network(self, args=()):
        self.preflight.stop()
        output = io.StringIO()
        with redirect_stdout(output):
            code = m.main(["--check-network", *args])
        return code, output.getvalue()

    @staticmethod
    def http_error(status):
        return urllib.error.HTTPError("https://cn.meta-api.vip/v1/models", status, "error", {},
                                      io.BytesIO(json.dumps({"error": KEY}).encode()))

    def test_model_aliases(self):
        for value, expected in [
            (None, "gpt-image-2.5-sunburst"), ("Flare", "gpt-image-2.5-flare"),
            ("Image 2.5 Flare", "gpt-image-2.5-flare"),
            ("SUNBURST", "gpt-image-2.5-sunburst"), ("Image 2", "gpt-image-2"),
            ("vendor/new-image-v3", "vendor/new-image-v3"),
        ]:
            self.assertEqual(m.resolve_image_model(value), expected)
        for value in ["2.5", "Image 2.5", "gpt-image-2.5", "", "random words"]:
            with self.subTest(value=value), self.assertRaises(ValueError):
                m.resolve_image_model(value)

    def test_all_models_are_sent_exactly_once(self):
        for model in ["gpt-image-2", "gpt-image-2.5-flare", "gpt-image-2.5-sunburst"]:
            self.out = self.root / (model + ".png")
            with patch.object(m, "request_json", return_value=(200, RESULT)) as request:
                code, text = self.call(["--model", model])
            self.assertEqual(code, 0, text)
            self.assertEqual(request.call_count, 1)
            url, key, body = request.call_args.args[:3]
            self.assertEqual(url, "https://cn.meta-api.vip/v1/images/generations")
            self.assertEqual(key, KEY)
            self.assertEqual(body["model"], model)
            self.assertEqual(body["response_format"], "b64_json")
            self.assertNotIn("tools", body)
            self.assertEqual(self.out.read_bytes(), PNG)
            self.assertNotIn(KEY, text)

    def test_model_name_in_artistic_text_is_not_a_model_choice(self):
        with patch.object(m, "request_json", return_value=(200, RESULT)) as request:
            code, _ = self.call(["--prompt", "A poster titled Flare"])
        self.assertEqual(code, 0)
        self.assertEqual(request.call_args.args[2]["model"], "gpt-image-2.5-sunburst")

    def test_ambiguous_model_stops_before_network(self):
        code, text = self.call(["--image-model", "Image 2.5"])
        self.assertEqual(code, 1)
        self.assertIn("choose Flare or Sunburst", text)
        self.check.assert_not_called()

    def test_dry_run_needs_no_key_and_does_not_probe(self):
        with patch.dict(os.environ, {}, clear=True), patch.object(m, "resolve_api_key") as key:
            code, text = self.call(["--image-model", "Flare", "--dry-run"])
        self.assertEqual(code, 0, text)
        self.assertEqual(json.loads(text.splitlines()[-1])["model"], "gpt-image-2.5-flare")
        key.assert_not_called()
        self.check.assert_not_called()
        self.assertFalse(self.out.exists())

    def test_missing_key_does_not_read_auth_files(self):
        with patch.dict(os.environ, {"NAN_API_KEY": KEY, "OPENAI_API_KEY": KEY}, clear=True), \
                patch.object(Path, "read_text", side_effect=AssertionError("Must not read auth files")):
            code, text = self.call()
        self.assertEqual(code, 1)
        self.assertIn("missing_api_key", text)
        self.check.assert_not_called()

    def test_conflicting_keys_stop_without_network(self):
        code, text = self.call(["--api-key", "other-test-credential"])
        self.assertEqual(code, 1)
        self.assertIn("credential_conflict", text)
        self.assertNotIn("other-test-credential", text)
        self.check.assert_not_called()

    def test_explicit_key_is_allowed_when_environment_is_empty(self):
        with patch.dict(os.environ, {}, clear=True), \
                patch.object(m, "request_json", return_value=(200, RESULT)) as request:
            code, _ = self.call(["--api-key", KEY])
        self.assertEqual(code, 0)
        self.assertEqual(request.call_args.args[1], KEY)

    def test_equal_keys_are_not_a_conflict(self):
        self.assertEqual(m.resolve_api_key(KEY), KEY)

    @unittest.skipUnless(os.name == "posix", "POSIX private storage")
    def test_local_key_is_private_and_loaded_without_environment(self):
        import stat
        path = m.save_local_api_key(KEY)
        self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o600)
        self.assertEqual(stat.S_IMODE(path.parent.stat().st_mode), 0o700)
        with patch.dict(os.environ, {}, clear=True):
            self.assertEqual(m.resolve_api_key(None), KEY)

    def test_explicit_environment_does_not_read_saved_credentials(self):
        with patch.object(m, "load_local_api_key", side_effect=AssertionError("Not needed")):
            self.assertEqual(m.resolve_api_key(None), KEY)

    @unittest.skipUnless(os.name == "posix", "POSIX private storage")
    def test_insecure_or_symlink_credentials_are_rejected(self):
        path = m.save_local_api_key(KEY)
        path.chmod(0o644)
        with self.assertRaises(m.SkillError):
            m.load_local_api_key()
        path.unlink()
        path.symlink_to(self.root / "other")
        with self.assertRaises(m.SkillError):
            m.load_local_api_key()
        with self.assertRaises(m.SkillError):
            m.save_local_api_key(KEY)

    @unittest.skipUnless(os.name == "posix", "POSIX private storage")
    def test_configure_key_does_not_print_it_or_use_network(self):
        output = io.StringIO()
        with patch.object(sys.stdin, "isatty", return_value=True), \
                patch.object(m.getpass, "getpass", return_value=KEY), \
                patch.object(m, "open_request") as network, redirect_stdout(output):
            result = m.cli(["--configure-key"])
        self.assertEqual(result, 0)
        self.assertNotIn(KEY, output.getvalue())
        self.assertEqual(m.load_local_api_key(), KEY)
        network.assert_not_called()

    def test_configure_key_requires_hidden_interactive_input(self):
        output = io.StringIO()
        with patch.object(sys.stdin, "isatty", return_value=False), redirect_stdout(output):
            result = m.cli(["--configure-key"])
        self.assertEqual(result, 1)
        self.assertFalse(m.LOCAL_CREDENTIAL_FILE.exists())

    def test_echoing_getpass_fallback_is_rejected(self):
        def unavailable(*args, **kwargs):
            warnings.warn("Unable to disable echo", m.getpass.GetPassWarning)
            raise AssertionError("Must stop before reading echoing input")
        with patch.object(m.getpass, "getpass", side_effect=unavailable):
            with self.assertRaises(m.SkillError) as result:
                m.read_hidden_key()
        self.assertEqual(result.exception.code, "hidden_input_unavailable")
        self.assertFalse(m.LOCAL_CREDENTIAL_FILE.exists())

    @unittest.skipUnless(os.name == "posix", "POSIX private storage")
    def test_malformed_config_never_echoes_file_contents(self):
        path = m.save_local_api_key(KEY)
        path.write_text("not-json-" + KEY)
        with patch.dict(os.environ, {}, clear=True):
            code, text = self.call()
        self.assertEqual(code, 1)
        self.assertNotIn(KEY, text)
        self.check.assert_not_called()

    def test_network_check_and_dry_run_do_not_read_local_credentials(self):
        with patch.object(m, "load_local_api_key", side_effect=AssertionError("Must not read key")):
            self.assertEqual(self.call(["--dry-run"])[0], 0)
            with patch.object(m, "open_request", side_effect=self.http_error(401)):
                self.assertEqual(self.network()[0], 0)

    def test_windows_storage_never_writes_plaintext(self):
        with patch.object(m, "IS_WINDOWS", True), \
                patch.object(m.windows_dpapi, "protect_key", return_value=b"encrypted-test-payload"), \
                patch.object(m.windows_dpapi, "unprotect_key", return_value=KEY):
            path = m.save_local_api_key(KEY)
            raw = path.read_text()
            self.assertNotIn(KEY, raw)
            self.assertNotIn('"api_key"', raw)
            self.assertEqual(json.loads(raw)["format"], "windows-dpapi-v1")
            self.assertEqual(m.load_local_api_key(), KEY)

    def test_windows_protection_failure_does_not_fall_back_to_plaintext(self):
        with patch.object(m, "IS_WINDOWS", True), \
                patch.object(m.windows_dpapi, "protect_key", side_effect=OSError("denied")):
            with self.assertRaises(m.SkillError) as result:
                m.save_local_api_key(KEY)
        self.assertEqual(result.exception.code, "credential_protection_failed")
        self.assertFalse(m.LOCAL_CREDENTIAL_FILE.exists())

    def test_windows_other_identity_reports_locked_and_preserves_file(self):
        with patch.object(m, "IS_WINDOWS", True), \
                patch.object(m.windows_dpapi, "protect_key", return_value=b"encrypted"):
            path = m.save_local_api_key(KEY)
            original = path.read_bytes()
            with patch.object(m.windows_dpapi, "unprotect_key", side_effect=OSError("wrong user")):
                with self.assertRaises(m.SkillError) as result:
                    m.load_local_api_key()
            self.assertEqual(result.exception.code, "local_credential_locked")
            self.assertEqual(path.read_bytes(), original)

    def test_windows_rejects_plaintext_credentials(self):
        with patch.object(m, "IS_WINDOWS", True):
            with self.assertRaises(m.SkillError) as result:
                m.decode_credential({"api_key": KEY})
        self.assertEqual(result.exception.code, "unsafe_credential_file")

    def test_encrypted_windows_credentials_are_not_reused_on_other_platforms(self):
        with patch.object(m, "IS_WINDOWS", False), self.assertRaises(m.SkillError):
            m.decode_credential({"format": "windows-dpapi-v1", "ciphertext": "abcd"})

    def test_corrupt_encrypted_credential_is_not_accepted(self):
        for ciphertext in ["invalid!", None, 123]:
            with self.subTest(ciphertext=ciphertext), patch.object(m, "IS_WINDOWS", True), \
                    self.assertRaises(m.SkillError):
                m.decode_credential({"format": "windows-dpapi-v1", "ciphertext": ciphertext})

    def test_check_credentials_is_offline_and_never_prints_the_key(self):
        output = io.StringIO()
        with patch.object(m, "open_request") as network, redirect_stdout(output):
            code = m.main(["--check-credentials"])
        self.assertEqual(code, 0)
        self.assertIn("CREDENTIAL_READY=yes", output.getvalue())
        self.assertIn("AUTH_CHECK=not_performed", output.getvalue())
        self.assertNotIn(KEY, output.getvalue())
        network.assert_not_called()
        self.check.assert_not_called()

    def test_check_credentials_rejects_generation_inputs(self):
        output = io.StringIO()
        with redirect_stdout(output):
            code = m.main(["--check-credentials", "--prompt", "must not generate"])
        self.assertEqual(code, 1)
        self.check.assert_not_called()

    def test_junction_is_treated_as_unsafe_storage(self):
        fake_path = unittest.mock.Mock()
        fake_path.lstat.return_value = unittest.mock.Mock(st_mode=0o40700, st_file_attributes=0x400)
        self.assertTrue(m.unsafe_storage_path(fake_path))

    @unittest.skipUnless(os.name == "posix", "POSIX subprocess storage")
    def test_saved_key_is_available_to_a_fresh_process(self):
        path = self.root / ".config" / "meta-api-imagegen" / "credentials.json"
        with patch.object(m, "LOCAL_CREDENTIAL_FILE", path):
            m.save_local_api_key(KEY)
        output = io.StringIO()
        environment = dict(SYSTEM_ENV, HOME=str(self.root), USERPROFILE=str(self.root))
        with patch.dict(os.environ, environment, clear=True), redirect_stdout(output):
            code = m.supervise(["--check-credentials"], 5)
        self.assertEqual(code, 0, output.getvalue())
        self.assertIn("CREDENTIAL_SOURCE=local_config", output.getvalue())
        self.assertNotIn(KEY, output.getvalue())

    @unittest.skipUnless(os.name == "nt", "Requires native Windows DPAPI")
    def test_native_windows_saved_key_is_available_to_a_fresh_process(self):
        path = self.root / ".config" / "meta-api-imagegen" / "credentials.json"
        with patch.object(m, "LOCAL_CREDENTIAL_FILE", path):
            m.save_local_api_key(KEY)
        self.assertNotIn(KEY, path.read_text())
        output = io.StringIO()
        environment = dict(SYSTEM_ENV, HOME=str(self.root), USERPROFILE=str(self.root))
        with patch.dict(os.environ, environment, clear=True), redirect_stdout(output):
            code = m.supervise(["--check-credentials"], 10)
        self.assertEqual(code, 0, output.getvalue())
        self.assertIn("CREDENTIAL_SOURCE=local_config", output.getvalue())
        self.assertNotIn(KEY, output.getvalue())

    def test_network_401_is_reachable_not_invalid_key(self):
        with patch.object(m, "open_request", side_effect=self.http_error(401)) as request, \
                patch.object(m, "resolve_api_key") as key:
            code, text = self.network()
        self.assertEqual(code, 0, text)
        self.assertIn("NETWORK_CHECK=passed", text)
        self.assertIn("AUTH_CHECK=not_performed", text)
        self.assertIn("GENERATION_SUBMITTED=no", text)
        req = request.call_args.args[0]
        self.assertEqual(req.get_method(), "GET")
        self.assertFalse(req.has_header("Authorization"))
        self.assertIsNone(req.data)
        key.assert_not_called()

    def test_network_200_does_not_read_model_body(self):
        response = Response(b"not needed")
        with patch.object(response, "read", side_effect=AssertionError("No body needed")), \
                patch.object(m, "open_request", return_value=response):
            code, _ = self.network()
        self.assertEqual(code, 0)
        self.assertTrue(response.closed)

    def test_preflight_403_is_not_a_key_error_and_blocks_generation(self):
        self.preflight.stop()
        with patch.object(m, "open_request", side_effect=self.http_error(403)), \
                patch.object(m, "request_json") as generation:
            code, text = self.call()
        self.assertEqual(code, 1)
        self.assertIn("network_http_rejected", text)
        self.assertIn("SUBMISSION_STATE=not_submitted", text)
        generation.assert_not_called()

    def test_network_10013_requests_permission_without_generation(self):
        denied = OSError("socket denied")
        denied.winerror = 10013
        self.preflight.stop()
        with patch.object(m, "open_request", side_effect=urllib.error.URLError(denied)), \
                patch.object(m, "request_json") as generation:
            code, text = self.call(["--image-model", "Flare"])
        self.assertEqual(code, 1)
        self.assertIn("network_permission_required", text)
        self.assertIn("ERROR_STAGE=preflight", text)
        self.assertIn("SUBMISSION_STATE=not_submitted", text)
        generation.assert_not_called()

    def test_nested_permission_error_is_classified(self):
        state = m.RequestState()
        state.stage = "preflight"
        error = urllib.error.URLError(PermissionError(13, "denied"))
        self.assertEqual(m.describe_error(error, state).code, "network_permission_required")

    def test_tls_error_is_not_misreported_as_permission_denied(self):
        state = m.RequestState()
        state.stage = "preflight"
        error = urllib.error.URLError(ssl.SSLCertVerificationError(1, "certificate verify failed"))
        self.assertEqual(m.describe_error(error, state).code, "tls_connection_failed")

    def test_dns_error_is_not_misreported_as_key_failure(self):
        state = m.RequestState()
        state.stage = "preflight"
        error = urllib.error.URLError(socket.gaierror(-2, "name not known"))
        self.assertEqual(m.describe_error(error, state).code, "network_connection_failed")

    def test_preflight_uses_same_host_before_the_single_post(self):
        self.preflight.stop()
        with patch.object(m, "open_request", side_effect=[
            self.http_error(401), Response(json.dumps(RESULT).encode())
        ]) as request:
            code, text = self.call(["--base-url", "https://meta-api.vip/v1"])
        self.assertEqual(code, 0, text)
        reqs = [c.args[0] for c in request.call_args_list]
        self.assertEqual([r.full_url for r in reqs], [
            "https://meta-api.vip/v1/models", "https://meta-api.vip/v1/images/generations"])
        self.assertFalse(reqs[0].has_header("Authorization"))
        self.assertEqual(reqs[1].get_header("Authorization"), "Bearer " + KEY)

    def test_network_mode_rejects_generation_input(self):
        with patch.object(m, "open_request") as request:
            code, text = self.network(["--prompt", "must not generate"])
        self.assertEqual(code, 1)
        request.assert_not_called()

    def test_http_errors_do_not_retry_or_change_models(self):
        for status in [400, 401, 403, 429, 500, 503]:
            with self.subTest(status=status), \
                    patch.object(m, "request_json", side_effect=self.http_error(status)) as request:
                code, text = self.call(["--image-model", "Flare"])
                self.assertEqual(code, 1)
                self.assertEqual(request.call_count, 1)
                self.assertIn("ERROR_STAGE=generation", text)
                self.assertIn(f"HTTP_STATUS={status}", text)
                self.assertNotIn(KEY, text)
                self.assertFalse(self.out.exists())

    def test_generation_timeout_does_not_claim_no_charge(self):
        with patch.object(m, "request_json", side_effect=TimeoutError("timed out")) as request:
            code, text = self.call()
        self.assertEqual(code, 1)
        self.assertIn("SUBMISSION_STATE=unknown", text)
        self.assertIn("network_timeout", text)
        self.assertEqual(request.call_count, 1)

    def test_invalid_result_is_not_success(self):
        for data in [{"data": []}, {"data": [{}]}, {"data": [{"b64_json": "invalid"}]},
                     {"data": [{"b64_json": base64.b64encode(b"<html>error</html>").decode()}]}]:
            with self.subTest(data=data), patch.object(m, "request_json", return_value=(200, data)):
                code, _ = self.call()
                self.assertEqual(code, 1)
                self.assertFalse(self.out.exists())

    def test_existing_output_is_preserved_before_network(self):
        self.out.write_bytes(b"user-owned")
        code, _ = self.call()
        self.assertEqual(code, 1)
        self.check.assert_not_called()
        self.assertEqual(self.out.read_bytes(), b"user-owned")

    def test_force_still_requires_a_valid_result(self):
        self.out.write_bytes(b"user-owned")
        with patch.object(m, "request_json", return_value=(200, {"data": []})):
            self.assertEqual(self.call(["--force"])[0], 1)
        self.assertEqual(self.out.read_bytes(), b"user-owned")
        with patch.object(m, "request_json", return_value=(200, RESULT)):
            self.assertEqual(self.call(["--force"])[0], 0)
        self.assertEqual(self.out.read_bytes(), PNG)

    def test_reference_edit_keeps_all_images_and_model(self):
        refs = [self.root / f"ref-{n}.png" for n in range(2)]
        for ref in refs:
            ref.write_bytes(PNG)
        with patch.object(m, "request_multipart_json", return_value=(200, RESULT)) as request:
            code, text = self.call(["--image-model", "Sunburst", "--image", str(refs[0]),
                                    "--image", str(refs[1]), "--mask", str(refs[0])])
        self.assertEqual(code, 0, text)
        url, key, fields, files = request.call_args.args[:4]
        self.assertTrue(url.endswith("/v1/images/edits"))
        self.assertEqual(fields["model"], "gpt-image-2.5-sunburst")
        self.assertEqual(files, [("image[]", str(refs[0])), ("image[]", str(refs[1])), ("mask", str(refs[0]))])

    def test_upload_does_not_expose_local_filename(self):
        ref = self.root / "private-person-name.png"
        ref.write_bytes(PNG)
        with patch.object(m, "open_request", return_value=Response(json.dumps(RESULT).encode())) as request:
            m.request_multipart_json("https://cn.meta-api.vip/v1/images/edits", KEY,
                                     {"model": "gpt-image-2"}, [("image", str(ref))], 10)
        body = request.call_args.args[0].data
        self.assertNotIn(b"private-person-name", body)
        self.assertIn(b'filename="input-0.png"', body)

    def test_download_failure_is_distinct_from_generation_failure(self):
        data = {"data": [{"url": "https://cdn.example/a.png"}]}
        error = m.SkillError("image_download_http_error", "Download failed", http_status=403)
        with patch.object(m, "request_json", return_value=(200, data)) as request, \
                patch.object(m, "download_image", side_effect=error):
            code, text = self.call()
        self.assertEqual(code, 1)
        self.assertIn("ERROR_STAGE=download", text)
        self.assertIn("SUBMISSION_STATE=response_received", text)
        self.assertIn("HTTP_STATUS=403", text)
        self.assertEqual(request.call_count, 1)
        self.assertFalse(self.out.exists())

    def test_url_result_is_saved_without_regeneration(self):
        data = {"data": [{"url": "https://cdn.example/a.png?signature=private"}]}
        with patch.object(m, "request_json", return_value=(200, data)) as request, \
                patch.object(m, "download_image", return_value=PNG):
            code, text = self.call()
        self.assertEqual(code, 0, text)
        self.assertEqual(request.call_count, 1)
        self.assertNotIn("signature", text)
        self.assertEqual(self.out.read_bytes(), PNG)

    def test_download_never_forwards_generation_key(self):
        connection = unittest.mock.Mock()
        connection.getresponse.return_value = Response(PNG)
        with patch.object(m, "validate_image_url", return_value=(urllib.parse.urlsplit("https://cdn.example/a.png"), "8.8.8.8")), \
                patch.object(urllib.request, "getproxies", return_value={}), \
                patch.object(m, "PinnedImageConnection", return_value=connection):
            self.assertEqual(m.download_image("https://cdn.example/a.png", 10), PNG)
        self.assertNotIn("Authorization", connection.request.call_args.kwargs["headers"])
        connection.close.assert_called_once()

    def test_private_result_urls_are_rejected(self):
        for url in ["http://cdn.example/a.png", "file:///etc/passwd", "https://user:pass@cdn.example/a.png"]:
            with self.subTest(url=url), self.assertRaises(ValueError):
                m.validate_image_url(url)
        for addr in ["127.0.0.1", "10.0.0.1", "169.254.169.254", "::1"]:
            with patch.object(socket, "getaddrinfo", return_value=[
                (socket.AF_INET, socket.SOCK_STREAM, 6, "", (addr, 443))
            ]), self.assertRaises(ValueError):
                m.validate_image_url("https://cdn.example/a.png")

    def test_result_redirect_is_revalidated(self):
        redirect = Response(b"")
        redirect.status = 302
        redirect.headers = {"Location": "https://other.example/b.png"}
        first, second = unittest.mock.Mock(), unittest.mock.Mock()
        first.getresponse.return_value = redirect
        second.getresponse.return_value = Response(PNG)
        public = [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("8.8.8.8", 443))]
        with patch.object(urllib.request, "getproxies", return_value={}), \
                patch.object(socket, "getaddrinfo", return_value=public) as dns, \
                patch.object(m, "PinnedImageConnection", side_effect=[first, second]):
            self.assertEqual(m.download_image("https://cdn.example/a.png", 10), PNG)
        self.assertEqual([c.args[0] for c in dns.call_args_list], ["cdn.example", "other.example"])
        self.assertNotIn("Authorization", first.request.call_args.kwargs["headers"])
        self.assertNotIn("Authorization", second.request.call_args.kwargs["headers"])

    def test_api_redirect_cannot_leak_key(self):
        req = urllib.request.Request("https://cn.meta-api.vip/v1/images/generations",
                                     headers={"Authorization": "Bearer " + KEY})
        self.assertIsNone(m.NoRedirect().redirect_request(req, None, 302, "", {}, "https://other.example"))

    def test_invalid_parameters_and_untrusted_host_stop_before_network(self):
        for args in [["--size", "1536*1024"], ["--timeout", "0"], ["--mask", "no.png"],
                     ["--output-format", "jpeg"], ["--base-url", "https://other.example"],
                     ["--base-url", "https://cn.meta-api.vip/v1/images/generations"]]:
            with self.subTest(args=args):
                code, _ = self.call(args)
                self.assertEqual(code, 1)
                self.check.assert_not_called()

    def test_legacy_responses_flags_are_rejected(self):
        for flag in ["--responses-only", "--responses-model"]:
            with self.subTest(flag=flag), redirect_stdout(io.StringIO()), \
                    patch("sys.stderr", new=io.StringIO()), self.assertRaises(SystemExit):
                m.main([flag])

    def test_file_permission_error_is_not_network_denial(self):
        state = m.RequestState()
        state.stage = "save"
        self.assertEqual(m.describe_error(PermissionError(13, "denied"), state).code, "file_permission_denied")

    def test_credential_permission_denial_does_not_request_new_key(self):
        state = m.RequestState()
        state.stage = "credentials"
        result = m.describe_error(PermissionError(13, "denied"), state)
        self.assertEqual(result.code, "credential_access_denied")
        self.assertIn("不要重复输入", result.action)

    def test_limits_and_redaction(self):
        with self.assertRaises(ValueError):
            m.read_limited(io.BytesIO(b"12345"), 4)
        text = m.redact_error(KEY + " sk-fake https://cdn.example/a?secret=value", KEY)
        self.assertNotIn(KEY, text)
        self.assertNotIn("sk-fake", text)
        self.assertNotIn("secret=value", text)

    def test_supervisor_uses_same_python_and_no_key_in_child_argv(self):
        child = unittest.mock.Mock()
        child.communicate.return_value = ("", None)
        child.returncode = 0
        child.poll.return_value = 0
        with patch.object(subprocess, "Popen", return_value=child) as spawn, redirect_stdout(io.StringIO()):
            code = m.supervise(["--api-key", KEY], 10)
        self.assertEqual(code, 0)
        argv = spawn.call_args.args[0]
        self.assertEqual(argv[0], sys.executable)
        self.assertNotIn(KEY, " ".join(argv))
        self.assertIn(KEY, child.communicate.call_args.args[0])
        child.wait.assert_called()

    def test_supervisor_reports_unverified_cleanup_as_failure(self):
        child = unittest.mock.Mock()
        child.communicate.return_value = ("", None)
        child.returncode = 0
        child.poll.return_value = 0
        child.wait.side_effect = PermissionError("denied")
        text = io.StringIO()
        with patch.object(subprocess, "Popen", return_value=child), redirect_stdout(text):
            code = m.supervise([], 10)
        self.assertEqual(code, 1)
        self.assertIn("OWNED_WORKER_EXITED=unverified", text.getvalue())
        self.assertNotIn("RESIDUAL_OWNED_WORKERS=0", text.getvalue())

    def test_supervisor_timeout_reaps_real_child(self):
        pid_file = self.root / "child.pid"
        program = (
            "import os,sys,time; from pathlib import Path; "
            "Path(sys.argv[1]).write_text(str(os.getpid())); "
            "print('STAGE=preflight',flush=True); "
            "print('SUBMISSION_STATE=not_submitted',flush=True); time.sleep(20)"
        )
        output = io.StringIO()
        start = time.monotonic()
        with redirect_stdout(output):
            code = m.supervise([], 0.5, [sys.executable, "-c", program, str(pid_file)])
        self.assertEqual(code, 1)
        self.assertLess(time.monotonic() - start, 4)
        self.assertIn("request_deadline_exceeded", output.getvalue())
        self.assertIn("RESIDUAL_OWNED_WORKERS=0", output.getvalue())
        if os.name != "nt" and pid_file.exists():
            with self.assertRaises(ProcessLookupError):
                os.kill(int(pid_file.read_text()), 0)

    def test_real_worker_rejects_missing_credentials_without_network(self):
        output = io.StringIO()
        with patch.dict(os.environ, dict(SYSTEM_ENV, HOME=str(self.root), USERPROFILE=str(self.root)), clear=True), redirect_stdout(output):
            code = m.supervise(["--prompt", "test", "--out", str(self.out)], 5)
        self.assertEqual(code, 1)
        self.assertIn("missing_api_key", output.getvalue())
        self.assertIn("RESIDUAL_OWNED_WORKERS=0", output.getvalue())


if __name__ == "__main__":
    unittest.main()
