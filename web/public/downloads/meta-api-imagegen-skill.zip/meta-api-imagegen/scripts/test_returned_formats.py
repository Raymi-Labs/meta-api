"""Offline regression checks for returned-format handling and overwrite boundaries."""
import base64
from contextlib import redirect_stdout
import io
from pathlib import Path
import socket
import tempfile
import unittest
from unittest.mock import patch

import meta_api_imagegen as m
from test_image_boundaries import PNG

# Signature fixtures exercise routing and byte preservation, not image decoding.
JPEG = b'\xff\xd8\xff\xe0fixture\xff\xd9'
WEBP = b'RIFF\x10\x00\x00\x00WEBPfixture'


class ReturnedFormats(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.root = Path(tmp.name)
        self.out = self.root / 'result.png'
        for target, options in [
            ('socket.socket', {'side_effect': AssertionError('Network prohibited')}),
            ('meta_api_imagegen.resolve_api_key', {'return_value': 'test-key'}),
            ('meta_api_imagegen.check_network', {'return_value': 401}),
        ]:
            mock = patch(target, **options)
            mock.start()
            self.addCleanup(mock.stop)

    def run_main(self, extra):
        log = io.StringIO()
        with redirect_stdout(log):
            code = m.main(['--out', str(self.out)] + extra)
        return code, log.getvalue()

    def test_formats_keep_original_bytes_and_correct_suffix(self):
        for raw, ext in [(JPEG, '.jpg'), (WEBP, '.webp'), (PNG, '.png')]:
            requested = self.root / ('format' + ext + '.png')
            with redirect_stdout(io.StringIO()):
                saved = m.save_image_bytes(raw, requested)
            self.assertEqual(saved.suffix, ext)
            self.assertEqual(saved.read_bytes(), raw)
        self.assertEqual(list(self.root.glob('*.part')), [])

    def test_base64_reports_real_path_and_posts_once(self):
        response = {'data': [{'b64_json': base64.b64encode(JPEG).decode()}]}
        with patch.object(m, 'request_json', return_value=(200, response)) as post:
            code, log = self.run_main(['--prompt', 'sea'])
        self.assertEqual(code, 0, log)
        post.assert_called_once()
        self.assertEqual(post.call_args.args[2]['output_format'], 'png')
        self.assertIn('WROTE_IMAGE=' + str(self.out.with_suffix('.jpg').resolve()), log)
        self.assertFalse(self.out.exists())
        self.assertEqual(self.out.with_suffix('.jpg').read_bytes(), JPEG)

    def test_url_download_uses_real_path_and_removes_recovery(self):
        with patch.object(m, 'request_json', return_value=(200, {'data': [{'url': 'https://example.com/image'}]})) as post, patch.object(m, 'download_image', return_value=JPEG) as download:
            code, log = self.run_main(['--prompt', 'sea'])
        self.assertEqual(code, 0, log)
        post.assert_called_once()
        download.assert_called_once()
        self.assertIn('WROTE_IMAGE=' + str(self.out.with_suffix('.jpg').resolve()), log)
        self.assertEqual(list(self.root.glob('.meta-recovery-*')), [])

    def test_resume_reports_real_path_without_generation(self):
        record = m.save_recovery('https://example.com/image', self.out)
        with patch.object(m, 'request_json') as post, patch.object(m, 'download_image', return_value=WEBP):
            code, log = self.run_main(['--resume', str(record)])
        self.assertEqual(code, 0, log)
        post.assert_not_called()
        self.assertIn('WROTE_IMAGE=' + str(self.out.with_suffix('.webp').resolve()), log)
        self.assertTrue(record.exists())

    def test_force_cannot_overwrite_changed_extension(self):
        sibling = self.out.with_suffix('.jpg')
        sibling.write_bytes(b'original')
        with self.assertRaises(FileExistsError), redirect_stdout(io.StringIO()):
            m.save_image_bytes(JPEG, self.out, force=True)
        self.assertEqual(sibling.read_bytes(), b'original')

    def test_changed_extension_cannot_overwrite_concurrent_creator(self):
        publish = m.publish_image
        def race(temporary, output, force):
            output.write_bytes(b'racer')
            publish(temporary, output, force)
        with patch.object(m, 'publish_image', side_effect=race), self.assertRaises(FileExistsError), redirect_stdout(io.StringIO()):
            m.save_image_bytes(JPEG, self.out, force=True)
        self.assertEqual(self.out.with_suffix('.jpg').read_bytes(), b'racer')
        self.assertEqual(list(self.root.glob('.meta-imagegen-*.part')), [])

    def test_invalid_data_still_rejected(self):
        with self.assertRaises(ValueError):
            m.save_image_bytes(b'<html>error</html>', self.out)
        self.assertEqual(list(self.root.iterdir()), [])
