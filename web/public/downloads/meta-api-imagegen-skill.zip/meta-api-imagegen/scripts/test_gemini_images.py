"""Native Gemini contract checks; never submit paid requests."""
import base64
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import urllib.error

import meta_api_imagegen as m
from test_meta_api_imagegen import PNG


def result(parts):
    return {"candidates": [{"content": {"parts": parts}}]}


class GeminiImages(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.out = Path(self.temp.name) / 'result.png'
        self.inline = {"inlineData": {"mimeType": "image/png", "data": base64.b64encode(PNG).decode()}}

    def run_main(self, options=(), response=None, error=None):
        output = io.StringIO()
        with patch.object(m, 'resolve_api_key', return_value='fake-key') as key, \
             patch.object(m, 'check_network') as preflight, \
             patch.object(m, 'request_json', return_value=(200, response if response is not None else result([self.inline])), side_effect=error) as request, \
             patch.object(m, 'request_multipart_json', side_effect=AssertionError('Unexpected edit')), \
             redirect_stdout(output):
            code = m.main(['--model', m.GEMINI_IMAGE_MODEL, '--prompt', 'A blue cube', '--out', str(self.out), *options])
        return code, output.getvalue(), request, key, preflight

    def test_native_endpoint_payload_and_real_save(self):
        code, output, request, _, _ = self.run_main()
        self.assertEqual(code, 0, output)
        self.assertEqual(self.out.read_bytes(), PNG)
        request.assert_called_once()
        url, key, body, timeout = request.call_args.args
        self.assertEqual(url, 'https://cn.meta-api.vip/v1beta/models/gemini-3.1-flash-image-preview:generateContent')
        self.assertEqual(body['generationConfig'], {'responseModalities': ['IMAGE'], 'candidateCount': 1, 'imageConfig': {'aspectRatio': '1:1', 'imageSize': '1K'}})
        self.assertEqual(body['contents'][0]['parts'], [{'text': 'A blue cube'}])
        self.assertIn('ROUTE=gemini-native', output)

    def test_dry_run_no_key_network_or_files(self):
        code, output, request, key, preflight = self.run_main(['--dry-run', '--resolution', '4K', '--aspect-ratio', '16:9'])
        self.assertEqual(code, 0, output)
        for fn in (request, key, preflight):
            fn.assert_not_called()
        self.assertFalse(self.out.exists())
        self.assertIn('unverified_resolution', output)
        body = next(json.loads(line) for line in output.splitlines() if line.startswith('{'))
        self.assertEqual(body['generationConfig']['imageConfig'], {'imageSize': '4K', 'aspectRatio': '16:9'})

    def test_incompatible_options_stop_before_credentials(self):
        for options in (['--image', 'missing.png'], ['--mask', 'missing.png'], ['--quality', 'high'], ['--size', '3840x2160'], ['--size', '1024x1024', '--resolution', '4K'], ['--output-format', 'webp']):
            with self.subTest(options=options):
                code, output, request, key, preflight = self.run_main(options)
                self.assertEqual(code, 1)
                self.assertIn('SUBMISSION_STATE=not_submitted', output)
                for fn in (request, key, preflight):
                    fn.assert_not_called()

    def test_empty_malformed_multiple_and_text_only_fail_once(self):
        for response in ({}, {'candidates': None}, {'candidates': [None]}, result([{'text': 'blocked'}]), result([self.inline, self.inline]), result([{'inlineData': {'mimeType': 'text/html', 'data': 'bad'}}]), result([{'inlineData': {'mimeType': 'image/png', 'data': 'bad'}}])):
            with self.subTest(response=str(response)[:70]):
                code, output, request, _, _ = self.run_main(response=response)
                self.assertEqual(code, 1)
                request.assert_called_once()
                self.assertFalse(self.out.exists())
                self.assertIn('SUBMISSION_STATE=response_received', output)

    def test_http_and_uncertain_transport_errors_not_retried(self):
        for error in (TimeoutError('timeout'), urllib.error.HTTPError('https://meta-api.vip/x', 429, 'limited', {}, io.BytesIO())):
            code, output, request, _, _ = self.run_main(error=error)
            self.assertEqual(code, 1)
            self.assertIn('SUBMISSION_STATE=unknown', output)
            request.assert_called_once()

    def test_unknown_model_stays_on_images_endpoint(self):
        code, output, request, _, _ = self.run_main(['--model', 'gemini-other-image'], response={'data': [{'b64_json': base64.b64encode(PNG).decode()}]})
        self.assertEqual(code, 0, output)
        self.assertTrue(request.call_args.args[0].endswith('/v1/images/generations'))
        self.assertEqual(request.call_args.args[2]['size'], '3840x2160')


if __name__ == '__main__':
    unittest.main()
