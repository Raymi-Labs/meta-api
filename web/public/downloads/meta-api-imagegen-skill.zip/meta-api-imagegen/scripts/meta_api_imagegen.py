#!/usr/bin/env python3
"""YuanHeng image APIs. One generation attempt; no model/key/host fallback."""
import argparse
import base64
import errno
import getpass
import http.client
import ipaddress
import json
import mimetypes
import os
from pathlib import Path
import re
import socket
import ssl
import stat
import subprocess
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import warnings
import uuid
from contextlib import contextmanager
import windows_dpapi


DEFAULT_IMAGE_MODEL = "gpt-image-2.5-sunburst"
GIF_IMAGE_MODEL = "gpt-image-2.6-sunburst"
GIF_IMAGE_MODELS = {GIF_IMAGE_MODEL, "gpt-image-2.6-flare"}
GEMINI_IMAGE_MODEL = "gemini-3.1-flash-image-preview"
GEMINI_ASPECT_RATIOS = ("1:1", "16:9", "9:16", "4:3", "3:4", "3:2", "2:3")
IS_WINDOWS = os.name == "nt"
TRUSTED_API_HOSTS = {"meta-api.com", "cn.meta-api.vip", "meta-api.vip", "nan.meta-api.vip"}
MAX_IMAGE_BYTES = 64 * 1024 * 1024
MAX_RESPONSE_BYTES = 96 * 1024 * 1024
LOCAL_CREDENTIAL_FILE = Path.home() / ".config" / "meta-api-imagegen" / "credentials.json"
MODEL_ALIASES = {
    "image-2.6-sunburst": "gpt-image-2.6-sunburst",
    "image2.6-sunburst": "gpt-image-2.6-sunburst",
    "image-2.6-flare": "gpt-image-2.6-flare",
    "image2.6-flare": "gpt-image-2.6-flare",
    "flare": "gpt-image-2.5-flare",
    "image2.5-flare": "gpt-image-2.5-flare",
    "image-2.5-flare": "gpt-image-2.5-flare",
    "sunburst": "gpt-image-2.5-sunburst",
    "image2.5-sunburst": "gpt-image-2.5-sunburst",
    "image-2.5-sunburst": "gpt-image-2.5-sunburst",
    "image2": "gpt-image-2",
    "image-2": "gpt-image-2",
}


class SkillError(Exception):
    def __init__(self, code, message, action="", http_status=None):
        super().__init__(message)
        self.code = code
        self.action = action
        self.http_status = http_status


class RequestState:
    def __init__(self):
        self.stage = "validation"
        self.submission = "not_submitted"

    def enter(self, stage, submission=None):
        self.stage = stage
        if submission is not None:
            self.submission = submission
        print(f"STAGE={self.stage}", flush=True)
        print(f"SUBMISSION_STATE={self.submission}", flush=True)


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def open_request(request, timeout):
    # Preserve the caller's proxy/sandbox environment; never change system policy.
    return urllib.request.build_opener(NoRedirect()).open(request, timeout=timeout)


def read_limited(response, limit):
    raw = response.read(limit + 1)
    if len(raw) > limit:
        raise ValueError("Response exceeds the size limit; no image was saved.")
    return raw


def resolve_image_model(value):
    if value is None:
        return DEFAULT_IMAGE_MODEL
    model = value.strip()
    alias = re.sub(r"\s+", "-", model.lower())
    if alias in {"2.5", "image2.5", "image-2.5", "gpt-image-2.5"}:
        raise ValueError("Image 2.5 is ambiguous: choose Flare or Sunburst.")
    if alias in MODEL_ALIASES:
        return MODEL_ALIASES[alias]
    if not model or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:/-]*", model):
        raise ValueError("Supply a complete model ID, Flare, Sunburst, or Image 2.")
    return model


def normalize_base_url(value):
    base = (value or "https://cn.meta-api.vip").strip().rstrip("/")
    parsed = urllib.parse.urlsplit(base)
    if (parsed.scheme != "https" or parsed.hostname not in TRUSTED_API_HOSTS
            or parsed.username or parsed.password or parsed.query or parsed.fragment
            or parsed.port not in {None, 443}):
        raise ValueError("Use a trusted YuanHeng HTTPS host; no credentials, queries, or custom ports.")
    if parsed.path not in {"", "/v1"}:
        raise ValueError("Use the base URL, optionally ending in /v1, not a full endpoint.")
    return base[:-3] if base.endswith("/v1") else base


def validate_local_key(key):
    if not isinstance(key, str) or not key or len(key) > 8192 or any(not 33 <= ord(c) <= 126 for c in key):
        raise SkillError("invalid_local_credential", "元衡密钥格式无效。",
                         "请重新配置非空密钥，不包含空格、换行或控制字符。")
    return key


def unsafe_storage_path(path):
    try:
        info = path.lstat()
    except FileNotFoundError:
        return False
    # Reject Windows junctions/reparse points as well as ordinary symlinks.
    return stat.S_ISLNK(info.st_mode) or bool(getattr(info, "st_file_attributes", 0) & 0x400)


def encode_credential(key):
    if not IS_WINDOWS:
        return {"api_key": key}
    try:
        ciphertext = windows_dpapi.protect_key(key)
        return {"format": "windows-dpapi-v1", "ciphertext": base64.b64encode(ciphertext).decode("ascii")}
    except (OSError, ValueError):
        raise SkillError("credential_protection_failed", "Windows 无法为当前用户加密凭据。",
                         "请在原 Windows 用户的正常终端配置；不会退回明文保存。") from None


def decode_credential(data):
    if not isinstance(data, dict):
        raise SkillError("invalid_local_credential", "本地凭据格式无效。")
    if data.get("format") == "windows-dpapi-v1":
        if not IS_WINDOWS:
            raise SkillError("credential_platform_mismatch", "此凭据绑定了原 Windows 用户。",
                             "不要跨账户或跨机器复制凭据文件；请在本机配置自己的令牌。")
        try:
            encrypted = base64.b64decode(data["ciphertext"], validate=True)
            return validate_local_key(windows_dpapi.unprotect_key(encrypted))
        except (OSError, ValueError, KeyError, TypeError):
            raise SkillError("local_credential_locked", "当前 Windows 身份无法解密已保存的凭据。",
                             "先确认与配置时为同一用户；若被沙箱隔离，请走正常授权流程读取，"
                             "不要反复输入密钥、扩大账户权限或绕过限制。") from None
    if IS_WINDOWS:
        raise SkillError("unsafe_credential_file", "Windows 凭据需要采用账户绑定加密格式。",
                         "请使用 --configure-key 重新配置，不要从其他机器复制明文密钥文件。")
    if data.get("format"):
        raise SkillError("invalid_local_credential", "无法识别的凭据格式。")
    return validate_local_key(data.get("api_key"))


def load_local_api_key():
    path = LOCAL_CREDENTIAL_FILE
    if unsafe_storage_path(path) or unsafe_storage_path(path.parent):
        raise SkillError("unsafe_credential_file", "拒绝读取符号链接形式的凭据文件。")
    try:
        flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
        fd = os.open(path, flags)
    except FileNotFoundError:
        return None
    with os.fdopen(fd, "r", encoding="utf-8") as handle:
        info = os.fstat(handle.fileno())
        if not stat.S_ISREG(info.st_mode):
            raise SkillError("unsafe_credential_file", "凭据必须是普通文件。")
        if not IS_WINDOWS and os.name == "posix" and (info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) & 0o077):
            raise SkillError("unsafe_credential_file", "本地凭据权限过宽或不属于当前用户。",
                             "请使用当前用户重新配置，文件只应允许本人读取。")
        raw = handle.read(16385)
    if len(raw) > 16384:
        raise SkillError("invalid_local_credential", "本地凭据文件过大。")
    try:
        data = json.loads(raw)
    except (ValueError, TypeError):
        raise SkillError("invalid_local_credential", "本地凭据文件格式无效。") from None
    return decode_credential(data)


def save_local_api_key(key):
    key = validate_local_key(key.strip())
    # Complete encryption before creating/writing any file on Windows.
    payload = encode_credential(key)
    path = LOCAL_CREDENTIAL_FILE
    if unsafe_storage_path(path) or unsafe_storage_path(path.parent):
        raise SkillError("unsafe_credential_file", "拒绝写入符号链接形式的凭据位置。")
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    if not IS_WINDOWS and os.name == "posix":
        if path.parent.stat().st_uid != os.getuid():
            raise SkillError("unsafe_credential_file", "凭据目录不属于当前用户。")
        path.parent.chmod(0o700)
    fd, temporary = tempfile.mkstemp(prefix=".credentials-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            if not IS_WINDOWS and os.name == "posix":
                os.fchmod(handle.fileno(), 0o600)
            json.dump(payload, handle)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return path


def read_hidden_key():
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", getpass.GetPassWarning)
            return getpass.getpass("请输入元衡密钥（输入不显示）：")
    except getpass.GetPassWarning:
        raise SkillError("hidden_input_unavailable", "当前终端无法可靠隐藏输入。",
                         "请在本人电脑的正常终端重新运行配置命令；不会回显或读取密钥。") from None


def resolve_api_key(explicit):
    configured = (os.getenv("META_API_KEY") or "").strip()
    explicit = (explicit or "").strip()
    if configured and explicit and configured != explicit:
        raise SkillError("credential_conflict", "META_API_KEY 与显式密钥不一致。",
                         "请先确认本次要使用的元衡令牌；不会自动选择或切换。")
    key = explicit or configured or load_local_api_key()
    if not key:
        raise SkillError("missing_api_key", "没有找到用户指定的元衡凭据。",
                         "已配置过时先确认同一系统用户及凭据读取权限；"
                         "首次使用请运行 --configure-key 或设置 META_API_KEY，不要把密钥贴到聊天中。")
    return key


def check_network(base_url, timeout):
    """GET only, no authentication or request body; never generate an image."""
    request = urllib.request.Request(
        base_url + "/v1/models", headers={"Accept": "application/json"}, method="GET"
    )
    print("CHECK_MODE=network_only", flush=True)
    print("AUTH_SENT=no", flush=True)
    try:
        with open_request(request, timeout=min(timeout, 15)) as response:
            status = response.status
            # Checking reachability does not require downloading the model list.
    except urllib.error.HTTPError as exc:
        status = exc.code
        exc.close()
    print("NETWORK_REACHABLE=yes", flush=True)
    print(f"PREFLIGHT_HTTP_STATUS={status}", flush=True)
    if status not in {200, 401}:
        raise SkillError(
            "network_http_rejected", "连接收到 HTTP 响应，但连通检查没有通过。",
            "请检查当前元衡地址或服务状态；此请求未带密钥，不能据此认定密钥无效。",
            status,
        )
    print("AUTH_CHECK=not_performed", flush=True)
    print("NETWORK_CHECK=passed", flush=True)
    return status


def get_prompt(args):
    if args.prompt and args.prompt_file:
        raise ValueError("Use --prompt or --prompt-file, not both.")
    if args.prompt_file:
        prompt = Path(args.prompt_file).read_text(encoding="utf-8").strip()
    else:
        prompt = (args.prompt or "").strip()
    if not prompt:
        raise ValueError("A non-empty --prompt or --prompt-file is required.")
    return prompt


def image_temporary_path(output_path, nonce):
    if not re.fullmatch(r"[0-9a-f]{32}", nonce):
        raise ValueError("Invalid temporary image identifier.")
    return Path(output_path).absolute().parent / f".meta-imagegen-{nonce}.part"


def cleanup_temporary_image(path):
    if path is None:
        return
    try:
        info = path.lstat()
    except FileNotFoundError:
        return
    if not stat.S_ISREG(info.st_mode) or unsafe_storage_path(path):
        raise OSError("Refusing to remove an unexpected temporary image entry.")
    if os.name == "posix" and info.st_uid != os.getuid():
        raise OSError("Temporary image belongs to another user.")
    path.unlink()


def publish_image(temporary, output, force):
    if force:
        os.replace(temporary, output)
    elif os.name == "nt":
        # Windows rename fails rather than overwriting a concurrently created file.
        os.rename(temporary, output)
    else:
        # An exclusive hard-link publication is atomic and cannot overwrite a racer.
        # Both files are in the same directory/filesystem. Fail closed if unsupported.
        os.link(temporary, output, follow_symlinks=False)


def gif_metadata(raw):
    """Read GIF blocks without re-encoding frames; no optional dependencies."""
    if len(raw) < 13 or raw[:6] not in (b"GIF87a", b"GIF89a"):
        raise ValueError("Invalid GIF header.")
    width = int.from_bytes(raw[6:8], "little")
    height = int.from_bytes(raw[8:10], "little")
    if not width or not height:
        raise ValueError("Invalid GIF dimensions.")
    pos = 13
    frames, duration, delay, loop = 0, 0, 0, None

    def take(n):
        nonlocal pos
        if pos + n > len(raw):
            raise ValueError("Truncated GIF data.")
        value = raw[pos:pos + n]
        pos += n
        return value

    def blocks():
        chunks = []
        while True:
            size = take(1)[0]
            if size == 0:
                return chunks
            chunks.append(take(size))

    if raw[10] & 128:
        take(3 * (2 ** ((raw[10] & 7) + 1)))
    while True:
        marker = take(1)[0]
        if marker == 0x3B:
            if not frames:
                raise ValueError("GIF contains no frames.")
            return {"width": width, "height": height, "frames": frames,
                    "duration_ms": duration, "loop": loop}
        if marker == 0x21:
            label = take(1)[0]
            chunks = blocks()
            if label == 0xF9:
                if len(chunks) != 1 or len(chunks[0]) != 4:
                    raise ValueError("Invalid GIF graphic control block.")
                delay = int.from_bytes(chunks[0][1:3], "little") * 10
            elif label == 0xFF and len(chunks) > 1:
                if chunks[0] in (b"NETSCAPE2.0", b"ANIMEXTS1.0") and len(chunks[1]) == 3 and chunks[1][0] == 1:
                    loop = int.from_bytes(chunks[1][1:3], "little")
        elif marker == 0x2C:
            descriptor = take(9)
            if descriptor[8] & 128:
                take(3 * (2 ** ((descriptor[8] & 7) + 1)))
            code_size = take(1)[0]
            if not 2 <= code_size <= 8 or not blocks():
                raise ValueError("Invalid GIF image block.")
            frames += 1
            duration += delay
            delay = 0
        else:
            raise ValueError("Invalid GIF block marker.")


def save_image_bytes(raw, output_path, force=False, temporary_path=None):
    if len(raw) > MAX_IMAGE_BYTES:
        raise ValueError("Image exceeds the size limit.")
    if raw.startswith(b"\x89PNG\r\n\x1a\n") and len(raw) >= 24:
        image_format = "png"
    elif raw.startswith(b"\xff\xd8\xff"):
        image_format = "jpeg"
    elif raw.startswith(b"RIFF") and raw[8:12] == b"WEBP":
        image_format = "webp"
    elif raw.startswith((b"GIF87a", b"GIF89a")):
        metadata = gif_metadata(raw)
        image_format = "gif"
        print("GIF_METADATA=" + json.dumps(metadata, separators=(",", ":")), flush=True)
    else:
        raise ValueError("Result is not PNG, JPEG, WebP, or GIF image data.")
    out = Path(output_path)
    expected = {".png": "png", ".jpg": "jpeg", ".jpeg": "jpeg", ".webp": "webp", ".gif": "gif"}.get(out.suffix.lower())
    if expected != image_format:
        out = out.with_suffix({"png": ".png", "jpeg": ".jpg", "webp": ".webp", "gif": ".gif"}[image_format])
        # --force authorizes only the exact requested path, not a sibling file.
        force = False
        print(f"OUTPUT_EXTENSION_ADJUSTED={out.suffix}", flush=True)
    print(f"IMAGE_FORMAT={image_format}", flush=True)
    if unsafe_storage_path(out) or (out.exists() and (not force or not out.is_file())):
        raise FileExistsError("Output exists or is not a regular file; it was not changed.")
    out.parent.mkdir(parents=True, exist_ok=True)
    temporary = temporary_path or image_temporary_path(out, uuid.uuid4().hex)
    if temporary.parent != out.absolute().parent or temporary == out.absolute():
        raise ValueError("Temporary image must be separate and in the output directory.")
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "wb") as handle:
            if handle.write(raw) != len(raw):
                raise OSError("Incomplete image write; original output was preserved.")
            handle.flush()
            os.fsync(handle.fileno())
        publish_image(temporary, out, force)
    finally:
        cleanup_temporary_image(temporary)
    return out


def save_base64_image(value, output_path, force=False, temporary_path=None):
    return save_image_bytes(base64.b64decode(value, validate=True), output_path, force, temporary_path)


def save_recovery(url, output_path):
    """Persist only the result locator, never prompts, keys or request bodies."""
    if len(url.encode("utf-8")) > 8192:
        raise ValueError("Image URL is too long for a recovery record.")
    payload = {"version": 1, "url": url}
    if IS_WINDOWS:
        payload = {"version": 1, "encrypted_url": base64.b64encode(
            windows_dpapi.crypt_bytes(url.encode("utf-8"))).decode("ascii")}
    parent = Path(output_path).absolute().parent
    parent.mkdir(parents=True, exist_ok=True)
    directory = Path(tempfile.mkdtemp(prefix=".meta-recovery-", dir=parent))
    record = directory / "result.json"
    temporary = directory / "result.part"
    try:
        fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, record)
    except BaseException:
        temporary.unlink(missing_ok=True)
        record.unlink(missing_ok=True)
        directory.rmdir()
        raise
    return record


def load_recovery(path):
    path = Path(path).expanduser()
    if unsafe_storage_path(path) or unsafe_storage_path(path.parent):
        raise ValueError("Recovery record must not be a symlink.")
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
    with os.fdopen(os.open(path, flags), "rb") as handle:
        info = os.fstat(handle.fileno())
        if not stat.S_ISREG(info.st_mode):
            raise ValueError("Recovery record must be a regular file.")
        if os.name == "posix" and (info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) & 0o077):
            raise ValueError("Recovery record must be private to the current user.")
        payload = json.loads(read_limited(handle, 32768))
    if not isinstance(payload, dict) or payload.get("version") != 1:
        raise ValueError("Unsupported recovery record.")
    if "encrypted_url" in payload:
        if not IS_WINDOWS:
            raise ValueError("This recovery record requires its original Windows user.")
        url = windows_dpapi.crypt_bytes(
            base64.b64decode(payload["encrypted_url"], validate=True), decrypt=True).decode("utf-8")
    else:
        if IS_WINDOWS:
            raise ValueError("Windows recovery records must use current-user encryption.")
        url = payload.get("url")
    if not isinstance(url, str) or not url or len(url.encode("utf-8")) > 8192:
        raise ValueError("Invalid recovery URL.")
    # The download path revalidates DNS, public IPs and TLS for every attempt.
    return url


def display_local_path(path):
    path = Path(path).absolute()
    try:
        return str(Path("~") / path.relative_to(Path.home()))
    except ValueError:
        return str(path)


def public_image_ip(value):
    if "%" in value:
        raise ValueError("Scoped addresses are not allowed for image downloads.")
    address = ipaddress.ip_address(value)
    if (not address.is_global or address.is_multicast or address.is_reserved
            or address.is_loopback or address.is_link_local or address.is_unspecified):
        raise ValueError("Refusing a non-public image address.")
    if isinstance(address, ipaddress.IPv6Address):
        if address.sixtofour or address.teredo:
            raise ValueError("IPv6 transition addresses are not supported for image downloads.")
        if address.ipv4_mapped and not address.ipv4_mapped.is_global:
            raise ValueError("Refusing a private IPv4-mapped image address.")
    return address


def validate_image_url(url):
    parsed = urllib.parse.urlsplit(url)
    if (parsed.scheme != "https" or not parsed.hostname or parsed.username
            or parsed.password or parsed.port not in {None, 443}):
        raise ValueError("Image URL must be a public HTTPS URL.")
    addresses = socket.getaddrinfo(parsed.hostname, 443, type=socket.SOCK_STREAM)
    if not addresses:
        raise ValueError("Refusing a non-public image URL.")
    validated = [public_image_ip(a[4][0]) for a in addresses]
    return parsed, str(validated[0])


class PinnedImageConnection(http.client.HTTPSConnection):
    def __init__(self, hostname, address, timeout):
        self.image_address = public_image_ip(address)
        context = ssl.create_default_context()
        context.set_alpn_protocols(["http/1.1"])
        super().__init__(hostname, port=443, timeout=timeout, context=context)

    def connect(self):
        # Connect to the validated numeric address, not a second DNS resolution.
        family = socket.AF_INET6 if self.image_address.version == 6 else socket.AF_INET
        raw = socket.socket(family, socket.SOCK_STREAM)
        try:
            raw.settimeout(self.timeout)
            address = str(self.image_address)
            raw.connect((address, 443, 0, 0) if family == socket.AF_INET6 else (address, 443))
            # TLS/SNI and certificate validation use the original hostname.
            self.sock = self._context.wrap_socket(raw, server_hostname=self.host)
        except BaseException:
            raw.close()
            raise


@contextmanager
def open_image_result(url, timeout):
    hostname = urllib.parse.urlsplit(url).hostname
    proxies = urllib.request.getproxies()
    if any(value for name, value in proxies.items() if name != "no") and not urllib.request.proxy_bypass(hostname or ""):
        raise SkillError(
            "image_download_proxy_unsupported",
            "当前代理环境无法保证图片 URL 的连接目标校验，已停止自动下载。",
            "不会绕过代理；请服务商提供已有图片的安全获取方式或 b64_json，不要重复生图。",
        )
    parsed, address = validate_image_url(url)
    connection = PinnedImageConnection(parsed.hostname, address, timeout)
    try:
        target = urllib.parse.urlunsplit(("", "", parsed.path or "/", parsed.query, ""))
        host = parsed.hostname.encode("idna").decode("ascii")
        authority = f"[{host}]" if ":" in host else host
        if parsed.port is not None:
            authority += f":{parsed.port}"
        connection.request("GET", target, headers={
            "Accept": "image/*",
            "Host": authority,
            "User-Agent": f"Python-urllib/{sys.version_info.major}.{sys.version_info.minor}",
        })
        response = connection.getresponse()
        if response.status != 200:
            raise urllib.error.HTTPError(url, response.status, "Image download response", response.headers, response)
        yield response
    finally:
        connection.close()


def download_image(url, timeout):
    for _ in range(6):
        try:
            with open_image_result(url, timeout=timeout) as response:
                return read_limited(response, MAX_IMAGE_BYTES)
        except urllib.error.HTTPError as exc:
            if exc.code in {301, 302, 303, 307, 308} and exc.headers.get("Location"):
                url = urllib.parse.urljoin(url, exc.headers["Location"])
                exc.close()
                continue
            status = exc.code
            exc.close()
            raise SkillError("image_download_http_error", "已收到图片地址，但下载失败。",
                             "不要重新生图；先处理原图片的访问问题，上游可能已计费。", status) from None
    raise ValueError("Too many image URL redirects; generation was not retried.")


def request_json(url, api_key, payload, timeout):
    request = urllib.request.Request(
        url, data=json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        method="POST",
    )
    with open_request(request, timeout=timeout) as response:
        return response.status, json.loads(read_limited(response, MAX_RESPONSE_BYTES).decode("utf-8"))


def request_multipart_json(url, api_key, fields, files, timeout):
    boundary = "----meta-api-imagegen-boundary"
    chunks = []
    for name, value in fields.items():
        chunks.extend([
            f"--{boundary}\r\n".encode(),
            f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode(),
            str(value).encode("utf-8"), b"\r\n",
        ])
    for index, (name, path) in enumerate(files):
        file = Path(path)
        mime = mimetypes.guess_type(file.name)[0] or "application/octet-stream"
        filename = f"input-{index}{file.suffix.lower()}"
        chunks.extend([
            f"--{boundary}\r\n".encode(),
            f'Content-Disposition: form-data; name="{name}"; filename="{filename}"\r\n'.encode(),
            f"Content-Type: {mime}\r\n\r\n".encode(), file.read_bytes(), b"\r\n",
        ])
    chunks.append(f"--{boundary}--\r\n".encode())
    request = urllib.request.Request(
        url, data=b"".join(chunks),
        headers={"Authorization": f"Bearer {api_key}",
                 "Content-Type": f"multipart/form-data; boundary={boundary}"}, method="POST",
    )
    with open_request(request, timeout=timeout) as response:
        return response.status, json.loads(read_limited(response, MAX_RESPONSE_BYTES).decode("utf-8"))


def configure_image_route(args):
    """Select a wire format before submission; model support is decided upstream."""
    if args.api_format == "auto":
        # Masks and Images-specific options have no equivalent native Gemini field.
        # Select their explicit wire format before POST, never retry another route.
        images_options = args.mask or args.quality is not None or args.output_format != "png" or args.size not in (None, "auto")
        args.api_format = "gemini" if args.image_model == GEMINI_IMAGE_MODEL and not images_options else "images"
    for value in (args.resolution, args.aspect_ratio, args.quality):
        if value is not None and not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9:._-]{0,63}", value):
            raise ValueError("Resolution, ratio and quality must be non-empty format tokens.")
    for value in (args.frame_count, args.frame_duration_ms):
        if value is not None and value <= 0:
            raise ValueError("Frame count and frame duration must be positive integers.")
    if args.output_format != "gif" and (args.frame_count is not None or args.frame_duration_ms is not None):
        raise ValueError("Frame parameters require GIF output.")
    if args.api_format == "gemini":
        if args.mask or args.quality is not None or args.output_format != "png" or args.size not in (None, "auto"):
            raise ValueError("Native Gemini has no Images mask/quality/pixel-size/output-format mapping; select --api-format images to send those fields unchanged.")
        args.size = "auto"
        args.resolution = args.resolution or "1K"
        args.aspect_ratio = args.aspect_ratio or "1:1"
    else:
        args.size = args.size or ("512x512" if args.output_format == "gif" else "3840x2160")
        args.quality = args.quality or ("medium" if args.output_format == "gif" else "high")
    if args.output_format == "gif":
        args.frame_count = args.frame_count if args.frame_count is not None else 9
        args.frame_duration_ms = args.frame_duration_ms if args.frame_duration_ms is not None else 200


def gemini_reference_part(filename):
    with Path(filename).open("rb") as stream:
        raw = stream.read(MAX_IMAGE_BYTES + 1)
    if len(raw) > MAX_IMAGE_BYTES:
        raise ValueError("Reference image exceeds the local file-size limit.")
    if raw.startswith(b"\x89PNG\r\n\x1a\n"):
        mime = "image/png"
    elif raw.startswith(b"\xff\xd8\xff"):
        mime = "image/jpeg"
    elif raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
        mime = "image/webp"
    else:
        raise ValueError("Gemini references must be PNG, JPEG or WebP.")
    return {"inlineData": {"mimeType": mime, "data": base64.b64encode(raw).decode("ascii")}}


def try_gemini_image_api(args, api_key, base_url, prompt, state):
    endpoint = "/v1beta/models/" + urllib.parse.quote(args.image_model, safe="-._") + ":generateContent"
    payload = {
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {
            "responseModalities": ["IMAGE"], "candidateCount": 1,
            "imageConfig": {"aspectRatio": args.aspect_ratio, "imageSize": args.resolution},
        },
    }
    print(f"TRY_DIRECT={base_url + endpoint} MODEL={args.image_model}", flush=True)
    references = []
    reference_bytes = 0
    for path in (args.images or []):
        part = gemini_reference_part(path)
        reference_bytes += len(part["inlineData"]["data"])
        if reference_bytes > MAX_RESPONSE_BYTES:
            raise ValueError("References exceed the local request-memory limit.")
        references.append(part)
    if args.dry_run:
        payload["contents"][0]["parts"].extend({"inlineData": {"mimeType": part["inlineData"]["mimeType"], "data": "[local reference image]"}} for part in references)
        print(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), flush=True)
        return True
    payload["contents"][0]["parts"].extend(references)
    state.enter("generation", "unknown")
    status, data = request_json(base_url + endpoint, api_key, payload, args.timeout)
    state.enter("result", "response_received")
    candidates = data.get("candidates") if isinstance(data, dict) else None
    if not isinstance(candidates, list) or len(candidates) != 1:
        raise ValueError("Gemini returned no single image candidate; no retry was attempted.")
    candidate = candidates[0]
    content = candidate.get("content") if isinstance(candidate, dict) else None
    parts = content.get("parts") if isinstance(content, dict) else None
    images = [part["inlineData"] for part in parts
              if isinstance(part, dict) and isinstance(part.get("inlineData"), dict)] if isinstance(parts, list) else []
    if len(images) != 1:
        raise ValueError("Gemini returned no single inline image; no retry was attempted.")
    image = images[0]
    if image.get("mimeType") not in {"image/png", "image/jpeg", "image/webp"}:
        raise ValueError("Gemini returned an unsupported inline image MIME type.")
    if not isinstance(image.get("data"), str) or not image["data"]:
        raise ValueError("Gemini returned empty inline image data.")
    state.enter("save")
    saved_path = save_base64_image(image["data"], args.out, args.force, args.temporary_image)
    state.enter("complete")
    print(f"HTTP_STATUS={status}")
    print("ROUTE=gemini-native")
    print(f"MODEL_REQUESTED={args.image_model}")
    print("IMAGE_SOURCE=inlineData")
    print(f"WROTE_IMAGE={saved_path.resolve()}", flush=True)
    return True


def try_direct_image_api(args, api_key, base_url, prompt, state=None):
    state = state or RequestState()
    endpoint = "/v1/images/edits" if args.images else "/v1/images/generations"
    payload = {
        "model": args.image_model, "size": args.size, "quality": args.quality,
        "n": 1, "output_format": args.output_format, "response_format": "b64_json",
    }
    if args.output_format == "gif":
        payload.update(frame_count=args.frame_count, frame_duration_ms=args.frame_duration_ms)
    if args.resolution:
        payload["resolution"] = args.resolution
    if args.aspect_ratio:
        payload["aspect_ratio"] = args.aspect_ratio
    print(f"TRY_DIRECT={base_url + endpoint} MODEL={args.image_model}", flush=True)
    if args.dry_run:
        plan = dict(payload, prompt=prompt)
        if args.images:
            plan.update(images=args.images, mask=args.mask)
        print(json.dumps(plan, ensure_ascii=False, separators=(",", ":")), flush=True)
        return True
    # "unknown" is conservative: a transport failure doesn't prove no billing.
    state.enter("generation", "unknown")
    if args.images:
        payload["prompt"] = prompt
        files = [("image[]" if len(args.images) > 1 else "image", path) for path in args.images]
        if args.mask:
            files.append(("mask", args.mask))
        status, data = request_multipart_json(base_url + endpoint, api_key, payload, files, args.timeout)
    else:
        status, data = request_json(base_url + endpoint, api_key, dict(payload, prompt=prompt), args.timeout)
    state.enter("result", "response_received")
    items = data.get("data") if isinstance(data, dict) else None
    if not isinstance(items, list) or not items or not isinstance(items[0], dict):
        raise ValueError("Direct Image API returned no image data; no fallback was attempted.")
    item = items[0]
    if isinstance(item.get("b64_json"), str) and item["b64_json"]:
        state.enter("save")
        saved_path = save_base64_image(item["b64_json"], args.out, args.force, args.temporary_image)
        source = "b64_json"
    elif isinstance(item.get("url"), str) and item["url"]:
        state.enter("download")
        recovery = None
        try:
            recovery = save_recovery(item["url"], args.out)
            print(f"RECOVERY_FILE={display_local_path(recovery)}", flush=True)
        except Exception:
            # A record failure must not discard an otherwise downloadable image.
            print("RECOVERY_WARNING=无法保存恢复记录；仍尝试获取本次原图，失败后请联系元衡。", flush=True)
        raw = download_image(item["url"], args.timeout)
        state.enter("save")
        saved_path = save_image_bytes(raw, args.out, args.force, args.temporary_image)
        if recovery is not None:
            try:
                recovery.unlink()
                recovery.parent.rmdir()
                print("RECOVERY_CLEANUP=done", flush=True)
            except OSError:
                print("RECOVERY_CLEANUP=unverified", flush=True)
        source = "url"
    else:
        raise ValueError("Direct Image API returned no b64_json/url; no fallback was attempted.")
    if args.output_format == "gif":
        raw_result = saved_path.read_bytes()
        if not raw_result.startswith((b"GIF87a", b"GIF89a")) or gif_metadata(raw_result)["frames"] < 2:
            print(f"WROTE_IMAGE={saved_path.resolve()}", flush=True)
            raise ValueError("Requested animated GIF but received a static result; original saved, no retry attempted.")
    state.enter("complete")
    print(f"HTTP_STATUS={status}")
    print("ROUTE=direct-images")
    print(f"MODEL_REQUESTED={args.image_model}")
    print(f"IMAGE_SOURCE={source}")
    print(f"WROTE_IMAGE={saved_path.resolve()}", flush=True)
    return True


def redact_error(text, *keys):
    for key in keys:
        if key:
            text = text.replace(key, "<redacted>")
    text = re.sub(r"sk-[A-Za-z0-9_-]+", "<redacted>", text)
    return re.sub(r"https?://[^\s\"'<>]+", "<url>", text)[:1000]


def exception_chain(exc):
    seen = set()
    while isinstance(exc, BaseException) and id(exc) not in seen:
        seen.add(id(exc))
        yield exc
        exc = getattr(exc, "reason", None) or exc.__cause__


def describe_error(exc, state):
    if isinstance(exc, SkillError):
        return exc
    chain = list(exception_chain(exc))
    if state.stage in {"preflight", "generation", "download"}:
        denied = any(isinstance(e, PermissionError)
                     or getattr(e, "winerror", None) == 10013
                     or (not isinstance(e, ssl.SSLError)
                         and getattr(e, "errno", None) in {errno.EACCES, errno.EPERM, 10013})
                     for e in chain)
        if denied:
            return SkillError(
                "network_permission_required", "当前执行环境拒绝网络访问（例如 WinError 10013）。",
                "请由 Codex 通过正常流程申请本次联网授权；不要关防火墙、绕过沙箱或换密钥。"
                + ("尚未提交生图。" if state.submission == "not_submitted"
                   else "先检查原请求结果，不要自动重发生图。"),
            )
        if any(isinstance(e, (TimeoutError, socket.timeout)) for e in chain):
            return SkillError("network_timeout", "网络请求超时。",
                              "未自动重试；若已开始生图，请先检查元衡日志，避免重复计费。")
        if any(isinstance(e, ssl.SSLError) for e in chain):
            return SkillError("tls_connection_failed", "TLS 连接或证书校验失败。",
                              "检查证书、代理及服务状态；不要关闭证书校验或自动切换域名。")
        if isinstance(exc, urllib.error.URLError) and not isinstance(exc, urllib.error.HTTPError):
            return SkillError("network_connection_failed", str(exc),
                              "检查 DNS、代理和网络连接；未自动更换域名、密钥或重新生图。")
    if isinstance(exc, urllib.error.HTTPError):
        if state.stage == "download":
            action = "只处理原图片下载；不要重新生成，上游可能已经计费。"
        elif exc.code in {401, 403}:
            action = "查看错误正文，在元衡检查令牌状态、模型权限或额度；不要自动换密钥。"
        elif exc.code == 503:
            action = "将请求 ID 交给元衡检查分组、模型和可用渠道；不需要重装 Skill。"
        else:
            action = "按真实错误处理；未自动更换模型、域名、凭据或重试。"
        return SkillError("generation_http_error", str(exc), action, exc.code)
    if isinstance(exc, PermissionError):
        if state.stage == "credentials":
            return SkillError("credential_access_denied", "当前任务无权访问用户的元衡凭据。",
                              "已配置过时不要重复输入；请通过正常审批读取指定配置，并确认使用原系统用户。")
        return SkillError("file_permission_denied", "当前执行环境无法访问所需文件。",
                          "选择可写输出目录或申请所需文件权限；不要重新生图。")
    code = "invalid_parameters" if state.stage == "validation" else "image_operation_failed"
    return SkillError(code, str(exc), "查看错误阶段；不要自动重复提交生图请求。")


def report_error(exc, state, keys=()):
    error = describe_error(exc, state)
    print(f"ERROR_CODE={error.code}")
    print(f"ERROR_STAGE={state.stage}")
    print(f"SUBMISSION_STATE={state.submission}")
    if error.http_status is not None:
        print(f"HTTP_STATUS={error.http_status}")
    print(f"ERROR={redact_error(str(error), *keys)}")
    print(f"ACTION={error.action}")
    if isinstance(exc, urllib.error.HTTPError):
        try:
            # Keep untrusted upstream text on one escaped line, not as fake status markers.
            print("ERROR_BODY=" + json.dumps(redact_error(exc.read(4096).decode("utf-8", "replace"), *keys),
                                            ensure_ascii=False))
        finally:
            exc.close()
    print("RETRY_PERFORMED=no", flush=True)


def build_parser():
    parser = argparse.ArgumentParser(description="YuanHeng Images API with network preflight; no fallback.")
    parser.add_argument("--api-key", help="Prefer META_API_KEY; conflicting credentials are rejected.")
    parser.add_argument("--base-url", default="https://cn.meta-api.vip")
    parser.add_argument("--prompt")
    parser.add_argument("--prompt-file")
    parser.add_argument("--image", dest="images", action="append")
    parser.add_argument("--mask")
    parser.add_argument("--out", default="output/imagegen/output.png")
    parser.add_argument("--image-model", "--model", help="Complete ID, Flare, Sunburst, or Image 2.")
    parser.add_argument("--size", help="Images pixel size; default 3840x2160. Gemini: use resolution/ratio.")
    parser.add_argument("--resolution", help="Forward requested resolution; native Gemini defaults to 1K.")
    parser.add_argument("--api-format", choices=["auto", "images", "gemini"], default="auto")
    parser.add_argument("--frame-count", type=int, help="GIF frame count, default 9")
    parser.add_argument("--frame-duration-ms", type=int, help="GIF frame interval in milliseconds, default 200")
    parser.add_argument("--aspect-ratio", help="Forward requested ratio; native Gemini defaults to 1:1.")
    parser.add_argument("--quality", default=None)
    parser.add_argument("--output-format", choices=["png", "jpeg", "webp", "gif"], default="png")
    parser.add_argument("--direct-only", "--try-direct-image-api", dest="direct_only", action="store_true",
                        help="Compatibility flag; use the model-specific direct image endpoint.")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--check-network", action="store_true",
                      help="GET /v1/models only, without a key; no prompt, generation, or files.")
    mode.add_argument("--configure-key", action="store_true",
                      help="Save your credential using hidden input; current-user DPAPI on Windows.")
    mode.add_argument("--check-credentials", action="store_true",
                      help="Check credential availability without printing it or making network requests.")
    mode.add_argument("--resume", metavar="RESULT_JSON",
                      help="Download an existing result only; no key, preflight or generation POST.")
    parser.add_argument("--skip-preflight", action="store_true",
                        help="Omit only the reachability GET in an already verified environment; not permission.")
    parser.add_argument("--timeout", type=int, default=420, help="Whole-command deadline in seconds.")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--dry-run", action="store_true", help="No keys, network requests, or output files.")
    return parser


def main(argv=None, temporary_nonce=None):
    """Worker core; cli() supervises its complete lifetime on every platform."""
    args = build_parser().parse_args(argv)
    state = RequestState()
    key = None
    try:
        if args.configure_key:
            if args.api_key or args.prompt or args.prompt_file or args.images or args.mask or args.dry_run:
                raise ValueError("--configure-key must be used without key arguments or generation input.")
            state.stage = "credentials"
            if not sys.stdin.isatty():
                raise SkillError("interactive_input_required", "请在交互式终端配置密钥；禁止回显输入。")
            entered = read_hidden_key()
            save_local_api_key(entered)
            if load_local_api_key() != entered.strip():
                raise SkillError("credential_verify_failed", "保存后的本地凭据验证失败。")
            print("LOCAL_CREDENTIAL_SAVED=yes")
            print("LOCAL_CREDENTIAL_VERIFIED=yes")
            if os.getenv("META_API_KEY") and os.getenv("META_API_KEY").strip() != entered.strip():
                print("CREDENTIAL_WARNING=现有 META_API_KEY 与新保存的凭据不同；它仍优先，请自行确认配置。")
            print("NETWORK_REQUESTS=0", flush=True)
            return 0
        if args.timeout <= 0:
            raise ValueError("--timeout must be positive.")
        args.temporary_image = image_temporary_path(args.out, temporary_nonce) if temporary_nonce else None
        base_url = normalize_base_url(args.base_url)
        if args.check_credentials:
            if args.dry_run or args.prompt or args.prompt_file or args.images or args.mask:
                raise ValueError("--check-credentials cannot be combined with generation input or --dry-run.")
            state.enter("credentials")
            key = resolve_api_key(args.api_key)
            source = ("explicit" if (args.api_key or "").strip() else
                      "environment" if (os.getenv("META_API_KEY") or "").strip() else "local_config")
            print(f"CREDENTIAL_SOURCE={source}")
            print("CREDENTIAL_READY=yes")
            print("AUTH_CHECK=not_performed")
            print("NETWORK_REQUESTS=0", flush=True)
            return 0
        if args.check_network:
            if args.dry_run or args.prompt or args.prompt_file or args.images or args.mask:
                raise ValueError("--check-network cannot be combined with generation input or --dry-run.")
            state.enter("preflight")
            check_network(base_url, args.timeout)
            print("GENERATION_SUBMITTED=no", flush=True)
            return 0
        if args.resume:
            if args.api_key or args.prompt or args.prompt_file or args.images or args.mask or args.skip_preflight:
                raise ValueError("--resume cannot be combined with credentials or generation input.")
            out = Path(args.out)
            if out.suffix.lower() not in {".png", ".jpg", ".jpeg", ".webp", ".gif"}:
                raise ValueError("Recovery output must use a PNG, JPEG, WebP or GIF extension.")
            if unsafe_storage_path(out) or (out.exists() and (not args.force or not out.is_file())):
                raise ValueError("Output already exists; choose a new path or explicitly use --force.")
            state.enter("recovery", "response_received")
            url = load_recovery(args.resume)
            print("GENERATION_SUBMITTED=no", flush=True)
            print("AUTH_SENT=no", flush=True)
            if args.dry_run:
                print("RECOVERY_CHECK=passed")
                print("NETWORK_REQUESTS=0", flush=True)
                return 0
            state.enter("download")
            raw = download_image(url, args.timeout)
            state.enter("save")
            saved_path = save_image_bytes(raw, args.out, args.force, args.temporary_image)
            state.enter("complete")
            print(f"WROTE_IMAGE={saved_path.resolve()}", flush=True)
            print("RECOVERY_RECORD_RETAINED=yes", flush=True)
            return 0
        prompt = get_prompt(args)
        args.image_model = resolve_image_model(args.image_model or (GIF_IMAGE_MODEL if args.output_format == "gif" else None))
        configure_image_route(args)
        if args.mask and not args.images:
            raise ValueError("--mask requires --image.")
        if not re.fullmatch(r"[1-9]\d*x[1-9]\d*|auto", args.size):
            raise ValueError("Use --size WIDTHxHEIGHT (for example 1536x1024), or auto.")
        for path in (args.images or []) + ([args.mask] if args.mask else []):
            if not Path(path).is_file():
                raise ValueError("A selected reference image or mask does not exist.")
        out = Path(args.out)
        if out.is_symlink() or (out.exists() and (not args.force or not out.is_file())):
            raise ValueError("Output already exists; choose a new path or explicitly use --force.")
        suffixes = {"png": {".png"}, "jpeg": {".jpg", ".jpeg"}, "webp": {".webp"}, "gif": {".gif"}}
        if out.suffix.lower() not in suffixes[args.output_format]:
            raise ValueError("--out extension must match --output-format.")
        if not args.dry_run:
            state.enter("credentials")
            key = resolve_api_key(args.api_key)
            if not args.skip_preflight:
                state.enter("preflight")
                check_network(base_url, args.timeout)
        if args.api_format == "gemini":
            try_gemini_image_api(args, key, base_url, prompt, state)
        else:
            try_direct_image_api(args, key, base_url, prompt, state)
        return 0
    except Exception as exc:
        report_error(exc, state, (key, args.api_key))
        return 1


def supervise(argv, timeout, command=None):
    """One child, same Python and permissions; reap only the process we started."""
    command = command or [sys.executable, "-B", str(Path(__file__).resolve()), "--_worker"]
    process = None
    output = ""
    result = 1
    options = build_parser().parse_args(argv)
    nonce = uuid.uuid4().hex
    temporary_image = None
    if not (options.check_network or options.check_credentials or options.configure_key or options.dry_run):
        temporary_image = image_temporary_path(options.out, nonce)
    try:
        process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
        output, _ = process.communicate(json.dumps({"argv": argv, "temporary_nonce": nonce}, ensure_ascii=False), timeout=timeout)
        print(output, end="", flush=True)
        result = process.returncode
    except (subprocess.TimeoutExpired, KeyboardInterrupt) as exc:
        if process is not None:
            try:
                process.kill()
                output, _ = process.communicate(timeout=5)
            except (OSError, subprocess.TimeoutExpired):
                captured = getattr(exc, "output", "") or ""
                output = captured.decode("utf-8", "replace") if isinstance(captured, bytes) else captured
            print(output, end="", flush=True)
        state = RequestState()
        for line in output.splitlines():
            if line.startswith("STAGE="):
                state.stage = line.split("=", 1)[1]
            elif line.startswith("SUBMISSION_STATE="):
                state.submission = line.split("=", 1)[1]
        # No stage output means worker progress is unknown, not "no charge".
        if not output:
            state.stage = "worker"
            state.submission = "unknown"
        code = "request_deadline_exceeded" if isinstance(exc, subprocess.TimeoutExpired) else "cancelled"
        report_error(SkillError(code, "本次命令已超时或取消。",
                                "未重试；若请求可能已提交，请先检查元衡日志及已有输出。"), state)
    except OSError:
        report_error(SkillError("worker_start_failed", "无法启动或访问本次 Python 工作进程。",
                                "检查当前任务的执行权限，不要修改系统安全策略。"), RequestState())
    finally:
        if process is not None:
            try:
                if process.poll() is None:
                    process.kill()
                process.wait(timeout=5)
                print("OWNED_WORKER_EXITED=yes")
                print("RESIDUAL_OWNED_WORKERS=0", flush=True)
                try:
                    # This path is derived from our private job nonce, never from
                    # upstream responses or stdout, and is cleaned only after exit.
                    cleanup_temporary_image(temporary_image)
                    print("TEMP_IMAGE_CLEANUP=done", flush=True)
                except OSError:
                    print("TEMP_IMAGE_CLEANUP=unverified", flush=True)
                    result = 1
            except (OSError, subprocess.TimeoutExpired):
                print("OWNED_WORKER_EXITED=unverified", flush=True)
                result = 1
            if process.stdin:
                process.stdin.close()
            if process.stdout:
                process.stdout.close()
    return result


def cli(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    args = build_parser().parse_args(argv)
    if args.configure_key or (args.dry_run and not args.resume) or args.timeout <= 0:
        return main(argv)
    deadline = min(args.timeout, 20) if args.check_network or args.check_credentials else args.timeout
    return supervise(argv, deadline)


if __name__ == "__main__":
    # Avoid locale-dependent output on Windows, including redirected stdout.
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace", line_buffering=True)
        sys.stderr.reconfigure(encoding="utf-8", errors="replace", line_buffering=True)
    if sys.argv[1:] == ["--_worker"]:
        try:
            job = json.loads(sys.stdin.buffer.read(4 * 1024 * 1024))
            worker_argv = job["argv"]
            if not isinstance(worker_argv, list) or not all(isinstance(x, str) for x in worker_argv):
                raise ValueError("Invalid worker arguments.")
        except (ValueError, KeyError, TypeError):
            print("ERROR_CODE=invalid_worker_input", flush=True)
            sys.exit(1)
        sys.exit(main(worker_argv, temporary_nonce=job.get("temporary_nonce")))
    sys.exit(cli())
