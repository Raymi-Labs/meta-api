"""Offline GIF integration checks: no credentials, network, or paid generation."""
import base64
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import meta_api_imagegen as m
from test_image_boundaries import PNG

# Actual two-frame 2x2 GIF, red then blue, 200ms each, endless loop.
GIF = base64.b64decode('R0lGODlhAgACAIEAAP8AAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQAFAAAACwAAAAAAgACAAAIBgABCAQQEAAh+QQBFAABACwAAAAAAgACAIEAAP8AAAAAAAAAAAAIBgABCAQQEAA7')


class GifTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.out = self.root / 'out.gif'
        self.net = patch('socket.socket', side_effect=AssertionError('No network allowed'))
        self.net.start()
        self.addCleanup(self.net.stop)

    def run_main(self, extra=(), response=GIF):
        log = io.StringIO()
        with patch.object(m, 'resolve_api_key', return_value='test-key'), patch.object(m, 'check_network'), patch.object(m, 'request_json', return_value=(200, {'data': [{'b64_json': base64.b64encode(response).decode()}]})) as post, redirect_stdout(log):
            code = m.main(['--prompt', 'cat waving', '--output-format', 'gif', '--out', str(self.out), *extra])
        return code, log.getvalue(), post

    def test_single_post_and_unchanged_gif(self):
        code, log, post = self.run_main()
        self.assertEqual(code, 0, log)
        post.assert_called_once()
        self.assertTrue(post.call_args.args[0].endswith('/v1/images/generations'))
        payload = post.call_args.args[2]
        for k, v in dict(model='gpt-image-2.6-sunburst', output_format='gif', size='512x512', quality='medium', frame_count=9, frame_duration_ms=200, n=1).items():
            self.assertEqual(payload[k], v)
        self.assertEqual(self.out.read_bytes(), GIF)
        self.assertEqual(m.gif_metadata(GIF), dict(width=2, height=2, frames=2, duration_ms=400, loop=0))
        self.assertIn('GIF_METADATA=', log)
        self.assertEqual(list(self.root.glob('.meta-imagegen-*.part')), [])

    def test_flare_is_not_replaced(self):
        code, log, post = self.run_main(['--image-model', 'gpt-image-2.6-flare'])
        self.assertEqual(code, 0, log)
        self.assertEqual(post.call_args.args[2]['model'], 'gpt-image-2.6-flare')

    def test_explicit_model_specs_and_edit_are_forwarded(self):
        code, log, post = self.run_main(["--model", "gpt-image-new", "--size", "3840x2160", "--quality", "high", "--frame-count", "24", "--frame-duration-ms", "80", "--aspect-ratio", "21:9"])
        self.assertEqual(code, 0, log)
        body = post.call_args.args[2]
        self.assertEqual((body["model"], body["size"], body["quality"], body["frame_count"], body["frame_duration_ms"], body["aspect_ratio"]), ("gpt-image-new", "3840x2160", "high", 24, 80, "21:9"))
        self.out.unlink()
        ref = self.root / "ref.png"
        ref.write_bytes(PNG)
        with patch.object(m, "request_multipart_json", return_value=(200, {"data": [{"b64_json": base64.b64encode(GIF).decode()}]})) as edit:
            code, log, post = self.run_main(["--image", str(ref), "--mask", str(ref)])
            self.assertEqual(code, 0, log)
            edit.assert_called_once()
            self.assertTrue(edit.call_args.args[0].endswith("/v1/images/edits"))
            self.assertEqual(len(edit.call_args.args[3]), 2)
            post.assert_not_called()

    def test_invalid_frame_values_fail_before_request(self):
        for extra in (["--frame-count", "0"], ["--frame-duration-ms", "-1"]):
            code, log, post = self.run_main(extra)
            self.assertEqual(code, 1)
            post.assert_not_called()

    def test_static_response_is_retained_but_not_success(self):
        code, log, post = self.run_main(response=PNG)
        self.assertEqual(code, 1, log)
        post.assert_called_once()
        self.assertEqual(self.out.with_suffix('.png').read_bytes(), PNG)
        self.assertIn('received a static result', log)
        self.assertIn('WROTE_IMAGE=', log)

    def test_single_frame_gif_not_reported_animated(self):
        frame_end = GIF.index(b'\x21\xf9', GIF.index(b'\x21\xf9') + 1)
        single = GIF[:frame_end] + b'\x3b'
        code, log, post = self.run_main(response=single)
        self.assertEqual(code, 1, log)
        post.assert_called_once()
        self.assertEqual(self.out.read_bytes(), single)

    def test_truncated_and_empty_gif_not_published(self):
        for raw in (b'GIF89a', GIF[:-1], GIF[:13]+b'\x3b'):
            with self.subTest(raw=raw), self.assertRaises(ValueError), redirect_stdout(io.StringIO()):
                m.save_image_bytes(raw, self.out)
            self.assertFalse(self.out.exists())

    def test_existing_target_preserved(self):
        self.out.write_bytes(b'original')
        code, log, post = self.run_main()
        self.assertEqual(code, 1, log)
        post.assert_not_called()
        self.assertEqual(self.out.read_bytes(), b'original')

    def test_real_extension_does_not_overwrite_sibling(self):
        self.out.write_bytes(b'original')
        with self.assertRaises(FileExistsError), redirect_stdout(io.StringIO()):
            m.save_image_bytes(GIF, self.out.with_suffix('.png'), force=True)
        self.assertEqual(self.out.read_bytes(), b'original')

    def test_result_url_keeps_gif_and_submits_once(self):
        with patch.object(m, 'resolve_api_key', return_value='test-key'), patch.object(m, 'check_network'), patch.object(m, 'request_json', return_value=(200, {'data': [{'url': 'https://example.com/result.gif'}]})) as post, patch.object(m, 'download_image', return_value=GIF) as download, redirect_stdout(io.StringIO()):
            code = m.main(['--prompt', 'cat', '--output-format', 'gif', '--out', str(self.out)])
        self.assertEqual(code, 0)
        post.assert_called_once()
        download.assert_called_once()
        self.assertEqual(self.out.read_bytes(), GIF)

    def test_failed_download_retains_recovery_without_resubmission(self):
        with patch.object(m, 'resolve_api_key', return_value='test-key'), patch.object(m, 'check_network'), patch.object(m, 'request_json', return_value=(200, {'data': [{'url': 'https://example.com/result.gif'}]})) as post, patch.object(m, 'download_image', side_effect=TimeoutError('timeout')) as download, redirect_stdout(io.StringIO()):
            code = m.main(['--prompt', 'cat', '--output-format', 'gif', '--out', str(self.out)])
        self.assertEqual(code, 1)
        post.assert_called_once()
        download.assert_called_once()
        self.assertFalse(self.out.exists())
        self.assertTrue(list(self.root.glob('.meta-recovery-*')))

    def test_resume_downloads_once_without_key_or_generation(self):
        record = m.save_recovery('https://example.com/result.gif', self.out)
        with patch.object(m, 'resolve_api_key', side_effect=AssertionError('No credentials')), patch.object(m, 'request_json') as post, patch.object(m, 'download_image', return_value=GIF) as download, redirect_stdout(io.StringIO()):
            code = m.main(['--resume', str(record), '--out', str(self.out)])
        self.assertEqual(code, 0)
        post.assert_not_called()
        download.assert_called_once()
        self.assertEqual(self.out.read_bytes(), GIF)

    def test_dry_run_without_credentials_or_files(self):
        log = io.StringIO()
        with patch.object(m, 'resolve_api_key', side_effect=AssertionError('No credentials')), redirect_stdout(log):
            code = m.main(['--dry-run', '--prompt', 'cat', '--output-format', 'gif', '--out', str(self.out)])
        self.assertEqual(code, 0, log.getvalue())
        payload = json.loads(log.getvalue().splitlines()[-1])
        self.assertEqual(payload['frame_count'], 9)
        self.assertFalse(self.out.exists())

    def test_static_defaults_unchanged(self):
        log = io.StringIO()
        with redirect_stdout(log):
            code = m.main(['--dry-run', '--prompt', 'cat'])
        self.assertEqual(code, 0)
        payload = json.loads(log.getvalue().splitlines()[-1])
        self.assertEqual(payload['model'], 'gpt-image-2.5-sunburst')
        self.assertEqual(payload['size'], '3840x2160')
        self.assertNotIn('frame_count', payload)


if __name__ == '__main__':
    unittest.main()
