"""Offline adversarial cases: interrupted writes and hostile image URL resolution."""
import base64
from contextlib import redirect_stdout
import errno
import io
import os
from pathlib import Path
import socket
import ssl
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch
import urllib.request

import meta_api_imagegen as m

PNG = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII="
)
PUBLIC = [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("8.8.8.8", 443))]
PRIVATE = [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("127.0.0.1", 443))]


class DummySocket:
    def __init__(self):
        self.connected = []
        self.closed = False

    def settimeout(self, value):
        self.timeout = value

    def connect(self, address):
        self.connected.append(address)

    def close(self):
        self.closed = True


class Boundaries(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="meta-boundary-test-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.out = self.root / "image.png"
        no_network = patch.object(socket, "socket", side_effect=AssertionError("Real network prohibited"))
        no_network.start()
        self.addCleanup(no_network.stop)

    def assert_no_temporary(self):
        self.assertEqual(list(self.root.glob(".meta-imagegen-*.part")), [])

    def test_disk_full_preserves_existing_file_and_removes_partial(self):
        self.out.write_bytes(b"original")
        real_fdopen = os.fdopen
        class InterruptedWriter:
            def __init__(self, fd, mode):
                self.handle = real_fdopen(fd, mode)
            def __enter__(self):
                return self
            def __exit__(self, *args):
                self.handle.close()
            def write(self, raw):
                self.handle.write(raw[:8])
                self.handle.flush()
                raise OSError(errno.ENOSPC, "simulated disk full")
        with patch.object(os, "fdopen", side_effect=InterruptedWriter), self.assertRaises(OSError):
            m.save_image_bytes(PNG, self.out, force=True)
        self.assertEqual(self.out.read_bytes(), b"original")
        self.assert_no_temporary()

    def test_flush_failure_preserves_original(self):
        self.out.write_bytes(b"original")
        with patch.object(os, "fsync", side_effect=OSError("simulated flush failure")), self.assertRaises(OSError):
            m.save_image_bytes(PNG, self.out, force=True)
        self.assertEqual(self.out.read_bytes(), b"original")
        self.assert_no_temporary()

    def test_replace_failure_preserves_original(self):
        self.out.write_bytes(b"original")
        with patch.object(os, "replace", side_effect=PermissionError("simulated denial")), self.assertRaises(OSError):
            m.save_image_bytes(PNG, self.out, force=True)
        self.assertEqual(self.out.read_bytes(), b"original")
        self.assert_no_temporary()

    def test_atomic_replace_does_not_modify_other_hard_links(self):
        original = self.root / "original.png"
        original.write_bytes(b"original")
        os.link(original, self.out)
        m.save_image_bytes(PNG, self.out, force=True)
        self.assertEqual(self.out.read_bytes(), PNG)
        self.assertEqual(original.read_bytes(), b"original")
        self.assert_no_temporary()

    def test_no_force_does_not_overwrite_a_concurrent_creator(self):
        publish = m.publish_image
        def racer(temporary, output, force):
            output.write_bytes(b"concurrent-file")
            publish(temporary, output, force)
        with patch.object(m, "publish_image", side_effect=racer), self.assertRaises(FileExistsError):
            m.save_image_bytes(PNG, self.out)
        self.assertEqual(self.out.read_bytes(), b"concurrent-file")
        self.assert_no_temporary()

    def test_symlink_target_is_not_overwritten(self):
        target = self.root / "target.png"
        target.write_bytes(b"original")
        try:
            self.out.symlink_to(target)
        except OSError:
            self.skipTest("Symlink creation not permitted in this test environment")
        with self.assertRaises(FileExistsError):
            m.save_image_bytes(PNG, self.out, force=True)
        self.assertEqual(target.read_bytes(), b"original")
        self.assert_no_temporary()

    def test_worker_timeout_removes_only_its_partial_file(self):
        self.out.write_bytes(b"original")
        unrelated = self.root / ".meta-imagegen-unrelated.part"
        unrelated.write_bytes(b"do not remove")
        program = (
            "import json,sys,time; from pathlib import Path; "
            "sys.path.insert(0,sys.argv[1]); import meta_api_imagegen as m; "
            "job=json.load(sys.stdin); args=m.build_parser().parse_args(job['argv']); "
            "temp=m.image_temporary_path(args.out,job['temporary_nonce']); "
            "temp.write_bytes(b'partial'); print('STAGE=save',flush=True); "
            "print('SUBMISSION_STATE=response_received',flush=True); time.sleep(20)"
        )
        output = io.StringIO()
        with redirect_stdout(output):
            code = m.supervise(["--out", str(self.out), "--prompt", "offline fixture"], 0.6,
                               [sys.executable, "-B", "-c", program, str(Path(m.__file__).parent)])
        self.assertEqual(code, 1)
        self.assertIn("TEMP_IMAGE_CLEANUP=done", output.getvalue())
        self.assertIn("RESIDUAL_OWNED_WORKERS=0", output.getvalue())
        self.assertEqual(self.out.read_bytes(), b"original")
        self.assertEqual(unrelated.read_bytes(), b"do not remove")
        self.assertEqual(list(self.root.glob(".meta-imagegen-*.part")), [unrelated])

    def test_stdout_cannot_authorize_deletion_of_another_file(self):
        victim = self.root / "unrelated.png"
        victim.write_bytes(b"preserve")
        process = Mock()
        process.communicate.return_value = ("TEMP_OUTPUT=" + str(victim) + "\n", None)
        process.returncode = 0
        process.poll.return_value = 0
        with patch.object(m.subprocess, "Popen", return_value=process), redirect_stdout(io.StringIO()):
            self.assertEqual(m.supervise(["--out", str(self.out)], 2), 0)
        self.assertEqual(victim.read_bytes(), b"preserve")

    def test_invalid_temporary_identifier_is_rejected(self):
        for nonce in ["../victim", "a" * 31, "A" * 32]:
            with self.subTest(nonce=nonce), self.assertRaises(ValueError):
                m.image_temporary_path(self.out, nonce)

    def test_rebinding_cannot_change_validated_connection_address(self):
        raw = DummySocket()
        with patch.object(socket, "getaddrinfo", side_effect=[PUBLIC, PRIVATE]) as dns:
            parsed, address = m.validate_image_url("https://cdn.example/image.png")
            connection = m.PinnedImageConnection(parsed.hostname, address, 5)
            self.assertTrue(connection._context.check_hostname)
            self.assertEqual(connection._context.verify_mode, ssl.CERT_REQUIRED)
            with patch.object(socket, "socket", return_value=raw), \
                    patch.object(ssl.SSLContext, "wrap_socket", return_value=raw) as tls:
                connection.connect()
            self.assertEqual(dns.call_count, 1)
            self.assertEqual(raw.connected, [("8.8.8.8", 443)])
            self.assertEqual(tls.call_args.kwargs["server_hostname"], "cdn.example")
            connection.close()
        self.assertTrue(raw.closed)

    def test_tls_failure_closes_socket_without_retry(self):
        raw = DummySocket()
        connection = m.PinnedImageConnection("cdn.example", "8.8.8.8", 5)
        with patch.object(socket, "socket", return_value=raw), \
                patch.object(ssl.SSLContext, "wrap_socket", side_effect=ssl.SSLError("certificate mismatch")), \
                self.assertRaises(ssl.SSLError):
            connection.connect()
        self.assertTrue(raw.closed)
        self.assertEqual(len(raw.connected), 1)

    def test_ipv6_connection_uses_validated_numeric_address(self):
        raw = DummySocket()
        connection = m.PinnedImageConnection("cdn.example", "2606:4700:4700::1111", 5)
        with patch.object(socket, "socket", return_value=raw) as factory, \
                patch.object(socket, "getaddrinfo", side_effect=AssertionError("No second DNS lookup")), \
                patch.object(ssl.SSLContext, "wrap_socket", return_value=raw):
            connection.connect()
        self.assertEqual(factory.call_args.args[0], socket.AF_INET6)
        self.assertEqual(raw.connected, [("2606:4700:4700::1111", 443, 0, 0)])
        connection.close()

    def test_special_and_nonpublic_addresses_are_rejected(self):
        for ip in ["127.0.0.1", "10.0.0.1", "169.254.169.254", "::1", "::ffff:127.0.0.1",
                   "224.0.0.1", "ff02::1", "2002:7f00:1::", "fe80::1%eth0"]:
            with self.subTest(ip=ip), self.assertRaises(ValueError):
                m.public_image_ip(ip)

    def test_any_private_dns_answer_rejects_entire_download(self):
        with patch.object(socket, "getaddrinfo", return_value=PUBLIC + PRIVATE), self.assertRaises(ValueError):
            m.validate_image_url("https://cdn.example/image.png")

    def test_proxy_is_never_silently_bypassed(self):
        with patch.object(urllib.request, "getproxies", return_value={"https": "http://proxy.example:8080"}), \
                patch.object(urllib.request, "proxy_bypass", return_value=False), \
                patch.object(m, "validate_image_url") as resolve, \
                patch.object(m, "PinnedImageConnection") as connection, self.assertRaises(m.SkillError) as result:
            m.download_image("https://cdn.example/image.png", 5)
        self.assertEqual(result.exception.code, "image_download_proxy_unsupported")
        resolve.assert_not_called()
        connection.assert_not_called()

    def test_redirect_to_private_address_never_connects(self):
        response = io.BytesIO()
        response.status = 302
        response.headers = {"Location": "https://internal.example/image.png"}
        connection = Mock()
        connection.getresponse.return_value = response
        with patch.object(urllib.request, "getproxies", return_value={}), \
                patch.object(socket, "getaddrinfo", side_effect=[PUBLIC, PRIVATE]), \
                patch.object(m, "PinnedImageConnection", return_value=connection) as factory, \
                self.assertRaises(ValueError):
            m.download_image("https://cdn.example/image.png", 5)
        self.assertEqual(factory.call_count, 1)
        connection.close.assert_called_once()

    def test_signed_query_and_explicit_host_port_are_preserved(self):
        response = io.BytesIO(PNG)
        response.status = 200
        connection = Mock()
        connection.getresponse.return_value = response
        with patch.object(urllib.request, "getproxies", return_value={}), \
                patch.object(socket, "getaddrinfo", return_value=PUBLIC), \
                patch.object(m, "PinnedImageConnection", return_value=connection):
            image = m.download_image("https://cdn.example:443/image.png?signature=opaque%2Fvalue", 5)
        self.assertEqual(image, PNG)
        self.assertEqual(connection.request.call_args.args, ("GET", "/image.png?signature=opaque%2Fvalue"))
        headers = connection.request.call_args.kwargs["headers"]
        self.assertEqual(headers["Host"], "cdn.example:443")
        self.assertNotIn("Authorization", headers)


if __name__ == "__main__":
    unittest.main()
