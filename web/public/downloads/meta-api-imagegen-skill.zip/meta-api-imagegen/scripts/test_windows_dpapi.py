"""Validate the Win32 interop contract with fake DLLs; native coverage is separate."""
import ctypes
import unittest
from unittest.mock import patch

import windows_dpapi as dp


class Function:
    def __init__(self, callback):
        self.callback = callback

    def __call__(self, *args):
        return self.callback(*args)


class FakeDLLs:
    def __init__(self, result=b"ciphertext", success=True, allocate=True):
        self.result, self.success, self.allocate = result, success, allocate
        self.calls = []
        self.freed = []
        self.buffers = []
        self.CryptProtectData = Function(lambda *args: self.operate("protect", *args))
        self.CryptUnprotectData = Function(lambda *args: self.operate("unprotect", *args))
        self.LocalFree = Function(lambda pointer: self.freed.append(pointer.value))

    def operate(self, operation, source, description, entropy, reserved, prompt, flags, output):
        src = ctypes.cast(source, ctypes.POINTER(dp.DataBlob)).contents
        ent = ctypes.cast(entropy, ctypes.POINTER(dp.DataBlob)).contents
        self.calls.append((operation, ctypes.string_at(src.pbData, src.cbData),
                           ctypes.string_at(ent.pbData, ent.cbData), description, reserved, prompt, flags))
        if self.allocate:
            buffer = ctypes.create_string_buffer(self.result)
            self.buffers.append(buffer)
            dest = ctypes.cast(output, ctypes.POINTER(dp.DataBlob)).contents
            dest.cbData = len(self.result)
            dest.pbData = ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte))
        return int(self.success)

    def load(self, name):
        assert name in {"crypt32.dll", "kernel32.dll"}
        return self


class DPAPITests(unittest.TestCase):
    def test_protection_is_user_scoped_and_noninteractive(self):
        dll = FakeDLLs()
        self.assertEqual(dp.crypt_bytes(b"test-only-input", loader=dll.load), b"ciphertext")
        op, data, entropy, description, reserved, prompt, flags = dll.calls[0]
        self.assertEqual(op, "protect")
        self.assertEqual(data, b"test-only-input")
        self.assertEqual(entropy, dp.ENTROPY)
        self.assertEqual(flags, 1)
        self.assertEqual(flags & 4, 0)
        self.assertIsNone(description)
        self.assertIsNone(reserved)
        self.assertIsNone(prompt)
        self.assertEqual(len(dll.freed), 1)

    def test_unprotect_uses_same_entropy_and_frees_output(self):
        dll = FakeDLLs(result=b"plaintext")
        self.assertEqual(dp.crypt_bytes(b"ciphertext", decrypt=True, loader=dll.load), b"plaintext")
        self.assertEqual(dll.calls[0][0], "unprotect")
        self.assertEqual(dll.calls[0][2], dp.ENTROPY)
        self.assertEqual(len(dll.freed), 1)

    def test_failed_operation_does_not_return_data(self):
        for allocated in [True, False]:
            dll = FakeDLLs(success=False, allocate=allocated)
            with self.assertRaises(OSError):
                dp.crypt_bytes(b"test-only-input", loader=dll.load)
            self.assertEqual(len(dll.freed), int(allocated))

    def test_invalid_output_is_rejected_and_freed(self):
        dll = FakeDLLs(result=b"")
        with self.assertRaises(OSError):
            dp.crypt_bytes(b"test-only-input", loader=dll.load)
        self.assertEqual(len(dll.freed), 1)

    def test_plaintext_is_tagged_and_validated(self):
        with patch.object(dp, "crypt_bytes", return_value=b"encrypted") as function:
            self.assertEqual(dp.protect_key("fake-key"), b"encrypted")
            self.assertEqual(function.call_args.args[0], dp.PREFIX + b"fake-key")
        with patch.object(dp, "crypt_bytes", return_value=dp.PREFIX + b"fake-key"):
            self.assertEqual(dp.unprotect_key(b"encrypted"), "fake-key")
        with patch.object(dp, "crypt_bytes", return_value=b"wrong-format"):
            with self.assertRaises(ValueError):
                dp.unprotect_key(b"encrypted")

    def test_blob_uses_32bit_length_on_64bit_hosts(self):
        self.assertEqual(ctypes.sizeof(dp.DataBlob._fields_[0][1]), 4)
        self.assertGreaterEqual(dp.DataBlob.pbData.offset, 4)


if __name__ == "__main__":
    unittest.main()
