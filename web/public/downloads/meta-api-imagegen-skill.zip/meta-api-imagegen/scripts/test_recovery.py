"""Offline recovery checks; never use live credentials or image services."""
import base64
from contextlib import redirect_stdout
import io
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
import unittest
from unittest.mock import patch

import meta_api_imagegen as m

PNG = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII="
)
URL = "https://cdn.example/image.png?signature=private-result-token"


class Recovery(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.root = Path(directory.name)
        self.out = self.root / "image.png"
        guard = patch.object(socket, "socket", side_effect=AssertionError("No live network"))
        guard.start()
        self.addCleanup(guard.stop)
        key = patch.object(m, "resolve_api_key", return_value="fake-key")
        self.key = key.start()
        self.addCleanup(key.stop)
        check = patch.object(m, "check_network")
        self.check = check.start()
        self.addCleanup(check.stop)
        post = patch.object(m, "request_json", return_value=(200, {"data": [{"url": URL}]}))
        self.post = post.start()
        self.addCleanup(post.stop)

    def run_main(self, args):
        stream = io.StringIO()
        with redirect_stdout(stream):
            code = m.main(args)
        return code, stream.getvalue()

    def records(self):
        return list(self.root.glob(".meta-recovery-*/result.json"))

    def test_failed_download_can_resume_without_key_preflight_or_post(self):
        with patch.object(m, "download_image", side_effect=TimeoutError):
            code, text = self.run_main(["--prompt", "fixture", "--out", str(self.out)])
        self.assertEqual(code, 1)
        self.assertIn("SUBMISSION_STATE=response_received", text)
        self.assertNotIn("private-result-token", text)
        self.assertNotIn("fake-key", text)
        record, = self.records()
        self.assertEqual(m.load_recovery(record), URL)
        if os.name == "posix":
            self.assertEqual(record.stat().st_mode & 0o777, 0o600)
            self.assertEqual(record.parent.stat().st_mode & 0o777, 0o700)
        self.key.reset_mock()
        self.check.reset_mock()
        self.post.reset_mock()
        with patch.object(m, "download_image", return_value=PNG) as download:
            code, text = self.run_main(["--resume", str(record), "--out", str(self.out)])
        self.assertEqual(code, 0, text)
        self.key.assert_not_called()
        self.check.assert_not_called()
        self.post.assert_not_called()
        download.assert_called_once_with(URL, 420)
        self.assertEqual(self.out.read_bytes(), PNG)
        self.assertTrue(record.exists())

    def test_successful_url_download_cleans_record(self):
        with patch.object(m, "download_image", return_value=PNG):
            code, text = self.run_main(["--prompt", "fixture", "--out", str(self.out)])
        self.assertEqual(code, 0, text)
        self.assertEqual(self.records(), [])
        self.post.assert_called_once()
        self.assertEqual(self.post.call_args.args[2]["response_format"], "b64_json")

    def test_base64_path_does_not_create_recovery_or_download(self):
        self.post.return_value = (200, {"data": [{"b64_json": base64.b64encode(PNG).decode()}]})
        with patch.object(m, "save_recovery") as record, patch.object(m, "download_image") as download:
            code, text = self.run_main(["--prompt", "fixture", "--out", str(self.out)])
        self.assertEqual(code, 0, text)
        record.assert_not_called()
        download.assert_not_called()

    def test_record_failure_does_not_prevent_delivery(self):
        with patch.object(m, "save_recovery", side_effect=PermissionError), \
                patch.object(m, "download_image", return_value=PNG):
            code, text = self.run_main(["--prompt", "fixture", "--out", str(self.out)])
        self.assertEqual(code, 0, text)
        self.assertIn("RECOVERY_WARNING=", text)
        self.assertEqual(self.out.read_bytes(), PNG)

    def test_save_failure_retains_record(self):
        with patch.object(m, "save_image_bytes", side_effect=OSError("disk full")), \
                patch.object(m, "download_image", return_value=PNG):
            code, text = self.run_main(["--prompt", "fixture", "--out", str(self.out)])
        self.assertEqual(code, 1)
        self.assertIn("ERROR_STAGE=save", text)
        self.assertEqual(len(self.records()), 1)

    def test_resume_dry_run_no_network_or_credential_access(self):
        record = m.save_recovery(URL, self.out)
        with patch.object(m, "download_image") as download:
            code, text = self.run_main(["--resume", str(record), "--out", str(self.out), "--dry-run"])
        self.assertEqual(code, 0, text)
        download.assert_not_called()
        self.key.assert_not_called()
        self.assertNotIn(URL, text)
        self.assertFalse(self.out.exists())

    def test_resume_rejects_generation_inputs_and_existing_output(self):
        record = m.save_recovery(URL, self.out)
        for extra in [["--prompt", "not allowed"], ["--api-key", "fake"], ["--skip-preflight"]]:
            code, text = self.run_main(["--resume", str(record), "--out", str(self.out)] + extra)
            self.assertEqual(code, 1, text)
        self.out.write_bytes(b"original")
        with patch.object(m, "download_image") as download:
            code, _ = self.run_main(["--resume", str(record), "--out", str(self.out)])
        self.assertEqual(code, 1)
        download.assert_not_called()
        self.assertEqual(self.out.read_bytes(), b"original")
        self.post.assert_not_called()

    def test_private_url_is_still_blocked_on_resume(self):
        record = m.save_recovery("https://127.0.0.1/image.png", self.out)
        with patch.object(m.urllib.request, "getproxies", return_value={}), \
                patch.object(socket, "getaddrinfo",
                             return_value=[(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("127.0.0.1", 443))]):
            code, text = self.run_main(["--resume", str(record), "--out", str(self.out)])
        self.assertEqual(code, 1)
        self.assertIn("non-public", text)
        self.assertTrue(record.exists())
        self.post.assert_not_called()

    def test_windows_record_encrypted_without_plaintext_fallback(self):
        with patch.object(m, "IS_WINDOWS", True), \
                patch.object(m.windows_dpapi, "crypt_bytes", return_value=b"cipher"):
            record = m.save_recovery(URL, self.out)
            self.assertNotIn(URL, record.read_text())
            with patch.object(m.windows_dpapi, "crypt_bytes", return_value=URL.encode()):
                self.assertEqual(m.load_recovery(record), URL)
        with patch.object(m, "IS_WINDOWS", True), \
                patch.object(m.windows_dpapi, "crypt_bytes", side_effect=OSError):
            with self.assertRaises(OSError):
                m.save_recovery(URL, self.out)
        self.assertEqual(len(self.records()), 1)

    def test_invalid_and_shared_records_rejected(self):
        record = m.save_recovery(URL, self.out)
        for payload in [[], {"version": 2}, {"version": 1, "url": 123}]:
            record.write_text(json.dumps(payload))
            with self.assertRaises(ValueError):
                m.load_recovery(record)
        if os.name == "posix":
            record.chmod(0o644)
            with self.assertRaises(ValueError):
                m.load_recovery(record)

    def test_skip_preflight_is_explicit_and_never_retries_post(self):
        self.post.side_effect = TimeoutError
        code, text = self.run_main(["--prompt", "fixture", "--out", str(self.out), "--skip-preflight"])
        self.assertEqual(code, 1)
        self.check.assert_not_called()
        self.post.assert_called_once()
        self.assertIn("SUBMISSION_STATE=unknown", text)

    def test_record_write_failure_leaves_no_partial_recovery(self):
        with patch.object(os, "fsync", side_effect=OSError("disk full")):
            with self.assertRaises(OSError):
                m.save_recovery(URL, self.out)
        self.assertEqual(list(self.root.iterdir()), [])

    def test_home_directory_is_hidden_in_recovery_log(self):
        with patch.object(Path, "home", return_value=self.root):
            display = m.display_local_path(self.root / "private" / "result.json")
        self.assertEqual(display, str(Path("~") / "private" / "result.json"))
        self.assertNotIn(str(self.root), display)

    def test_recovery_dry_run_uses_supervisor(self):
        with patch.object(m, "supervise", return_value=0) as supervise:
            code = m.cli(["--resume", "record.json", "--dry-run", "--timeout", "3"])
        self.assertEqual(code, 0)
        self.assertEqual(supervise.call_args.args[1], 3)

    def test_recovery_worker_timeout_retains_record_and_exits(self):
        record = m.save_recovery(URL, self.out)
        program = (
            "import json,sys,time; "
            "sys.path.insert(0,sys.argv[1]); import meta_api_imagegen as m; "
            "job=json.load(sys.stdin); "
            "m.download_image=lambda *a: time.sleep(30); "
            "sys.exit(m.main(job['argv'], temporary_nonce=job['temporary_nonce']))"
        )
        stream = io.StringIO()
        with redirect_stdout(stream):
            code = m.supervise(["--resume", str(record), "--out", str(self.out)], 0.6,
                               [sys.executable, "-B", "-c", program, str(Path(m.__file__).parent)])
        self.assertEqual(code, 1)
        self.assertIn("RESIDUAL_OWNED_WORKERS=0", stream.getvalue())
        self.assertIn("SUBMISSION_STATE=response_received", stream.getvalue())
        self.assertEqual(m.load_recovery(record), URL)
        self.assertFalse(self.out.exists())

    def test_expired_url_is_not_a_reason_to_generate_again(self):
        record = m.save_recovery(URL, self.out)
        error = m.SkillError("image_download_http_error", "expired", http_status=403)
        with patch.object(m, "download_image", side_effect=error) as download:
            code, text = self.run_main(["--resume", str(record), "--out", str(self.out)])
        self.assertEqual(code, 1)
        self.assertIn("HTTP_STATUS=403", text)
        download.assert_called_once()
        self.post.assert_not_called()
        self.assertTrue(record.exists())


if __name__ == "__main__":
    unittest.main()
