"""Current-user Windows DPAPI only. No third-party dependencies or machine scope."""
import ctypes
import os


class DataBlob(ctypes.Structure):
    _fields_ = [("cbData", ctypes.c_uint32), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]


ENTROPY = b"yuanheng-meta-imagegen-credential-v1"
PREFIX = b"yuanheng:image-key:v1\0"


def _system_dll(name):
    if os.name != "nt":
        raise OSError("Windows DPAPI is unavailable on this platform.")
    # Do not load a DLL with the same name from the working directory.
    return ctypes.WinDLL(name, use_last_error=True, winmode=0x00000800)


def crypt_bytes(data, decrypt=False, loader=None):
    loader = loader or _system_dll
    crypt32, kernel32 = loader("crypt32.dll"), loader("kernel32.dll")
    function = crypt32.CryptUnprotectData if decrypt else crypt32.CryptProtectData
    function.argtypes = [
        ctypes.POINTER(DataBlob), ctypes.c_void_p, ctypes.POINTER(DataBlob),
        ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint32, ctypes.POINTER(DataBlob),
    ]
    function.restype = ctypes.c_int
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p
    source = ctypes.create_string_buffer(data)
    entropy = ctypes.create_string_buffer(ENTROPY)
    source_blob = DataBlob(len(data), ctypes.cast(source, ctypes.POINTER(ctypes.c_ubyte)))
    entropy_blob = DataBlob(len(ENTROPY), ctypes.cast(entropy, ctypes.POINTER(ctypes.c_ubyte)))
    output = DataBlob()
    try:
        # CRYPTPROTECT_UI_FORBIDDEN = 1. Never set CRYPTPROTECT_LOCAL_MACHINE = 4.
        if not function(ctypes.byref(source_blob), None, ctypes.byref(entropy_blob),
                        None, None, 1, ctypes.byref(output)):
            raise OSError("Windows DPAPI operation failed for the current user.")
        if not output.pbData or not 0 < output.cbData <= 16384:
            raise OSError("Windows DPAPI returned invalid data.")
        return ctypes.string_at(output.pbData, output.cbData)
    finally:
        if output.pbData:
            kernel32.LocalFree(ctypes.cast(output.pbData, ctypes.c_void_p))


def protect_key(key):
    return crypt_bytes(PREFIX + key.encode("ascii"))


def unprotect_key(ciphertext):
    plaintext = crypt_bytes(ciphertext, decrypt=True)
    if not plaintext.startswith(PREFIX):
        raise ValueError("Decrypted credential has the wrong format.")
    return plaintext[len(PREFIX):].decode("ascii")
