# Banana Gemini 图片流程

复用 `scripts/meta_api_imagegen.py`，只对完整模型 ID `gemini-3.1-flash-image-preview` 使用 `/v1beta/models/{model}:generateContent`。其他型号不因名称包含 Gemini 就自动切换协议，也不把 Lite、Pro、稳定版或未知别名改成此模型。

## 正常使用

用户可以说：“用香蕉生图生成一张蓝色立方体图片。”指定域名优先，未指定时沿用技能原有域名偏好。示例：

```bash
python3 scripts/meta_api_imagegen.py --base-url https://meta-api.vip \
  --model gemini-3.1-flash-image-preview --prompt '白色背景上的蓝色立方体，无文字' \
  --resolution 1K --aspect-ratio 1:1 --out output/banana.png
```

默认1K、1:1；支持明确传入1K/2K/4K及列出的常用比例（1:1、16:9、9:16、4:3、3:4、3:2、2:3）。已验证的是1K正方形；2K/4K及其他比例参数可传，但不代表上游稳定或已验收，4K曾有拒绝和超时，不自动降规格重试。实际尺寸以返回图片为准。

不传 `--quality high`、3840×2160等 Images API 默认值。需要调整 Gemini 规格时使用 `--resolution` 和 `--aspect-ratio`。不支持本型号的 `--image`/`--mask` 编辑；传入会在联网和读取密钥前拒绝，不会悄悄丢弃参考图。保留完整模型 ID。

脚本只发一次原生请求，明确要求IMAGE模态、一个候选；提取唯一inlineData图片，以实际PNG/JPEG/WebP字节保存。文本回复、空候选、多图片、错误或格式不符不能视为成功，也不会回退Chat或Images API。沿用原有凭据读取、网络预检、单次提交状态、输出保护、超时回收和展示验收流程。

`--dry-run` 不读密钥、不联网、不写输出；本次Skill适配使用离线回归，之前站内接口已验证不等于本轮再次收费生成。

## 视频可用性边界

Grok、Muse与雪天Grok别名已有视频脚本配置。Gemini Omni/Veo Lite的本地视频配置不等于当前线上视频路由已开放；当前已知部署/路由问题未解决时说明限制，不把Gemini图片协议套到视频、不擅自更换上游。用户提供密钥权限不代表供应商端点已配通。
