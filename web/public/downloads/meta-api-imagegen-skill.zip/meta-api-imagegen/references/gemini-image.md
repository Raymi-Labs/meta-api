# Gemini 原生生图

同一 `scripts/meta_api_imagegen.py` 支持原生 `/v1beta/models/{model}:generateContent` 与 Images接口。保留完整模型ID；未知Gemini型号使用原生协议时明确传 `--api-format gemini`，不自动换型号或失败重发。

`--api-format auto`仅对已知 `gemini-3.1-flash-image-preview` 的原生参数自动选择Gemini；其他型号或Images专用mask/quality/pixel-size/output-format输入选Images。可用`--api-format images`显式选择兼容接口。路由在POST前确定。

```bash
python3 scripts/meta_api_imagegen.py --base-url https://meta-api.com \
  --api-format gemini --model gemini-3.1-flash-image-preview \
  --image reference.png --prompt '保留人物，改为夜晚灯光' \
  --resolution 4K --aspect-ratio 21:9 --out output/gemini.png
```

原生Gemini将每张PNG/JPEG/WebP参考图编码为 `contents.parts[].inlineData`，保留顺序，提示词为text part；明确分辨率/比例映射到 `generationConfig.imageConfig`，默认1K/1:1。不因未实测限制分辨率/比例或参考图。单图64 MiB、总base64请求96 MiB是资源保护。

原生Gemini没有对应Images的mask、quality、像素size语义；若需要这些字段，用Images格式发送，不悄悄丢字段或把蒙版当普通参考图。显式`--api-format gemini`与这些字段冲突时给出格式错误。这是协议映射约束，不是模型能力结论。

一次请求只取一个图片结果，保留原始PNG/JPEG/WebP字节；实际返回格式可能改变文件扩展名，以`WROTE_IMAGE`交付。空/错误/非图片结果报告失败，不自动切换接口再生成。dry-run隐藏参考图base64、不读取密钥或联网。未实测参数不提前拒绝，最终可用性以接口结果为准。
