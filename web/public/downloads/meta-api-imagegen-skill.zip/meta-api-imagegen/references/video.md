# 视频生成、续查与下载

使用 `scripts/meta_api_video.py`（Python 3.9+）。新任务默认 `https://meta-api.com`，保留用户明确指定的旧元衡域名。密钥沿用 `META_API_KEY` → 本技能本地凭据顺序，不改变聊天模型。

## 参数原则

完整保留用户指定的型号、时长、分辨率、比例与参考图。已实测只是证据，不是白名单或上限；1080p、其他时长/比例、多图等由接口判断是否接受。失败报告实际错误，不自动降级、换模型、换协议或再次生成。

| 请求格式 | 默认映射 | 默认参数 |
| --- | --- | --- |
| xAI | 已知Grok两个型号；`duration/resolution/aspect_ratio`，单图`image.url`、多图`images` | 合并Skill5秒/480p/16:9 |
| Seedance | `doubao-seedance-2-5-260628`；`seconds/resolution/metadata`，参考图`images` | 4秒/720p/16:9 |
| OpenAI兼容 | Muse、Omni、雪天别名及其他完整模型ID；`seconds/resolution/aspect_ratio`，单图`input_reference`、多图`images` | 4秒/720p/16:9；Omni1080p别名默认1080p |

使用 `--protocol auto|openai|xai|seedance` 在提交前选择格式。未知型号默认统一视频格式，不猜厂商专属端点；不能因此声称所有型号都可用。`--size WIDTHxHEIGHT`可显式传像素；不认识的分辨率/比例保留原值，不默默转为720p。参考图支持本地PNG/JPEG/WebP，按顺序编码；保留20 MiB单文件、64 MiB总读取预算作为本地资源保护。`--image`与`--images`不能同时传。

Veo Lite沿用用户退役决定，继续禁止新提交，允许旧任务恢复。Seedance Key目前需企业级分组；不增加强制报价或权限查询步骤。

## 使用

正常交付指定 `--out`，助手负责一次提交、等待和下载：

```bash
python3 scripts/meta_api_video.py --base-url https://meta-api.com \
  --model doubao-seedance-2-5-260628 --duration 8 --resolution 1080p \
  --aspect-ratio 9:16 --prompt '白色纸船在池塘缓慢漂浮' \
  --state output/video/task.json --out output/video/result.mp4
```

这个例子展示参数传递，不代表1080p做过新的收费验收。Muse、Omni、Grok同样允许明确参数和参考图。原有Muse60秒及Seedance720p等实测记录只证明对应样本，不用于禁止其他调用。

完成时只显示原元衡域名下的鉴权content地址；`--out`携带原密钥下载MP4，检查实际时长、尺寸和音轨数量，返回本地成品。旧服务器即使返回上游链接也不会打印/跟随。格式元数据检查不保证视觉效果，仍需预览。`--dry-run`不联网、不读凭据、不写任务记录，参考图数据隐藏。

## 中断、续查与下载失败

```bash
# 仅查询原任务；完成后下载
python3 scripts/meta_api_video.py --resume --state work/video/muse-task.json \
  --out work/video/muse.mp4

# 已完成任务只重取文件；绝不POST，也不重新查询生成状态
python3 scripts/meta_api_video.py --download-only --state work/video/muse-task.json \
  --out work/video/muse-recovered.mp4 --download-timeout 900
```

- `submission_unknown`且无ID：先核对任务/账单，不删记录重试。
- `pending`、排队、生成中：只续查原ID。临时GET错误有界退避；明确unknown且ID匹配最多容忍连续三次，持续未知会保留ID停止。
- `failed`：报告并查账，不自动POST；不保证任意失败都不扣费。
- 下载失败保留completed记录，只用 `--download-only`；不要重生成、换密钥或把密钥发给CDN。
- 下载独立预算默认900秒，可设1–3600秒；512 MiB上限，流式写入私有临时文件，不HEAD、不依赖Range。中断后的自有临时文件需核对清理，不能删他人文件。
- 同一凭据指纹与原域名用于恢复。原图只在第一次提交时需要。
- 有界工作进程由父进程终止并回收；最终等待命令退出并确认遗留测试进程为零。

