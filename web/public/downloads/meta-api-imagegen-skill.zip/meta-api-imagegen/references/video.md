# 元衡视频流程

使用本Skill的 `scripts/meta_api_video.py`，Python 3.9+、标准库即可。沿用用户指定的元衡域名和凭据，不自动换模型、密钥或上游。默认域名为 `https://meta-api.com`。参考图只发送给元衡及所选渠道；不上传无关文件。生成授权不等于可以自动重发。

## 已验证范围与模型

| 模型 | 参数支持 | 已验证边界 |
|---|---|---|
| `muse-video` | 4–180秒整数、720p、16:9/9:16；默认4秒 | 经元衡Skill验收60秒、1280×720、24fps、1条音轨，生成526秒，完整下载；单图已验收；180秒未由本会话实测 |
| `grok-imagine-video` | 1–15秒、480p/720p；本地默认5秒 | 单图已通过元衡，1秒480p请求实际约1.04秒736×400/24fps，不保证输出尺寸恰为标称值 |
| `grok-imagine-video-1.5` | 显式选模，1–15秒，可请求1080p | 单图1秒480p已复测成功；其他分辨率未由本次验收 |
| `flow-video-gemini-omni-flash-1.1` | 4秒720p，文生 | 元衡提交/查询/下载通过，4秒1280×720/24fps |
| `flow-video-gemini-omni-flash-1.1-1080p` | 4秒1080p，文生 | 元衡链路通过，约3.92秒1920×1080/24fps；上游放大输出 |
| `snow-grok-imagine-video` | 4秒720p，文生 | 独立雪天别名，已通过原有链路，不等于原版CPA路由 |

**Veo Lite已放弃，不再允许新提交。** 旧任务仍可用恢复记录查询/取回；不要重新推荐或替换用户选定型号。TK、GetToken MiniMax、CentOS未纳入本次恢复或测试。

表中“参数支持”不是全部规格稳定性的证明。用户说长片已测好但没给具体规格时，不将其扩大成全部时长、分辨率或多图效果已验证。

## Muse图片与长片

- `--image first.png`：一张首帧；`--images first.png character.jpg scene.webp style.png`：1–4张有序参考图，两者互斥。
- 第1张为首帧，后3张为人物、场景或风格参考，不是尾帧。PNG/JPEG/WebP；单张≤10,000,000字节，合计≤24,000,000字节。不得默默压缩、丢图或将多图拼成一张冒充原生多图。
- **四图输入接受过（含WebP），但效果未通过验收**：60秒测试抽帧主要保留首图，后三图关键元素没有明显出现。可以按用户明确要求提交，不宣称多图一致性稳定。
- 提示词最多4000字符。超过30秒按上游文档由短片段拼接，不保证连续长镜头；按约30秒一段描述分镜。
- 上游文档称4/5秒出5秒，7/8出8秒，9/10出10秒，11秒以上向上取5秒档。**按请求秒数收费**，查询回显seconds不是实际媒体时长。本次60秒请求实际60秒；此前4秒请求实际5秒。
- 长于30秒的Muse默认等待1800秒，其他任务420秒；显式 `--wait` 优先。恢复根据原任务时长选择等待，不更换任务。

## 一次提交并交付文件

默认给每个新任务一个独立、私有恢复记录及未使用的输出文件名。正常交付传 `--out`，不要只返回“完成”或需要鉴权的链接。

```bash
python3 scripts/meta_api_video.py --model muse-video --duration 60 \
  --images first.png character.jpg --resolution 720p --aspect-ratio 16:9 \
  --prompt '两段各30秒：第一段……；第二段……，人物参考第二张图。' \
  --state work/video/muse-task.json --out work/video/muse.mp4
```

凭据使用进程 `META_API_KEY`，否则复用 `~/.config/meta-api-imagegen/credentials.json`。不读其他应用凭据、不在命令行/日志/恢复记录中放密钥。独立视频Skill仅用环境变量。

脚本只POST一次，保存ID后GET轮询。任务完成后，`--out`通过**同一元衡域名的任务content接口**携带原密钥流式下载，拒绝重定向、非MP4及覆盖已有文件；图片、提示词不写恢复文件。返回 `delivered` 时包含实际MP4时长、视频宽高与音轨数量。基础媒体检测不保证每帧画质或音轨有声，仍应预览成片；不因不满意而自动重生成。

`--dry-run`不联网、不读凭据、不写记录；图片数据在预览中隐藏。它不能证明上游可用。

## 中断、续查与下载失败

```bash
# 仅查询原任务；完成后下载
python3 scripts/meta_api_video.py --resume --state work/video/muse-task.json \
  --out work/video/muse.mp4

# 已完成任务只重取文件；绝不POST，也不重新查询生成状态
python3 scripts/meta_api_video.py --download-only --state work/video/muse-task.json \
  --out work/video/muse-recovered.mp4 --download-timeout 900
```

- `submission_unknown`且无ID：先核对任务/账单，不删记录重试。
- `pending`、排队、生成中：只续查原ID。临时GET错误有界退避；明确unknown且ID匹配最多容忍连续三次，持续未知会保留ID停止。
- `failed`：报告并查账，不自动POST；不保证任意失败都不扣费。
- 下载失败保留completed记录，只用 `--download-only`；不要重生成、换密钥或把密钥发给CDN。
- 下载独立预算默认900秒，可设1–3600秒；512 MiB上限，流式写入私有临时文件，不HEAD、不依赖Range。中断后的自有临时文件需核对清理，不能删他人文件。
- 同一凭据指纹与原域名用于恢复。原图只在第一次提交时需要。
- 有界工作进程由父进程终止并回收；最终等待命令退出并确认遗留测试进程为零。

## 价格与验收记录（2026-10-31）

价格不是Skill常量，实际以站内配置/任务快照和账单为准。按媒体组0.25、正常充值¥0.20/闪电：Muse最新为**3闪电/请求秒，约¥0.60/秒**，60秒180闪电、180秒540闪电。上游成本按用户确认¥1购入$1余额及$0.20/请求秒计算。图片不另加价。

已完成的60秒测试在调价前扣**120闪电**、上游$12余额；之后的改价不追溯旧任务。本次60秒输出与请求相同，无法据此额外证明所有向上凑档的长片计费；保留短片4秒出5秒的历史证据。180秒未测试是因当时余额$30.34不足$36，未自动充值。

Omni720p和雪天Grok别名现为0.75闪电/秒，Omni1080p为1.5闪电/秒。上述现金利润假设不适用于CPA Grok账号或其他购入方式，不宣称所有视频永不亏损。


2026-10-31 Grok 1.5 单图复测通过：经元衡Skill一次提交、自动查询与下载，1秒480p请求产出约1.042秒、736×400、24fps、1音轨，参考图图形/颜色/标记保留；渠道1577扣1.5闪电。其他分辨率未由本次验证。Muse180秒为上游保证支持，本会话未独立实测；多图效果问题暂不处理。

## Seedance 2.5 与公开下载地址（2026-11-11）

`doubao-seedance-2-5-260628` 已加入固定验收配置：4秒、720p、16:9、文生视频；用户Key需要企业级分组权限。提交采用 `seconds:"4"`、`resolution:"720p"`、`metadata:{ratio:"16:9",generate_audio:true,watermark:false}`。原线上样本产出4.042秒、1280×720、24fps，生成及鉴权取片均成功；本次Skill更新仅用离线夹具验证，没有新收费请求。1080p、其他时长/比例和参考图尚未在本配置验收，脚本明确拒绝而不是自动降级。

```bash
python3 scripts/meta_api_video.py --base-url https://meta-api.com \
  --model doubao-seedance-2-5-260628 --duration 4 --resolution 720p \
  --prompt '一只白色纸船在平静池塘中缓慢漂浮。' \
  --state output/video/seedance-task.json --out output/video/seedance.mp4
```

新任务未指定域名时使用 `.com`；明确传入的 `.vip`/`cn.meta-api.vip`/`nan.meta-api.vip`继续有效。恢复旧任务始终使用记录中的原域名和原凭据。完成输出只显示原元衡域名的 `/v1/videos/{task_id}/content`，带 `requires_authorization:true`；忽略服务端原始上游结果链接，`--out`仍自动携带原密钥保存MP4。没有`--out`时仅得到鉴权地址，不把它当匿名分享链接。服务器隐藏上游字段的修复需用户部署后才在线上生效。
