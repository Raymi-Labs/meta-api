#!/usr/bin/env python3
"""One paid JSON submission, resumable polling, and no credential persistence."""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import struct
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request

HOSTS = {"meta-api.com", "meta-api.vip", "cn.meta-api.vip", "nan.meta-api.vip"}
SEEDANCE_MODEL = "doubao-seedance-2-5-260628"
MODEL = "grok-imagine-video"
MODELS = {MODEL, "grok-imagine-video-1.5"}
COMPAT_PROFILES = {
    SEEDANCE_MODEL: (4, "720p", False),
    "flow-video-gemini-omni-flash-1.1": (4, "720p", False),
    "flow-video-gemini-omni-flash-1.1-1080p": (4, "1080p", False),
    "muse-video": (4, "720p", False),
    "snow-grok-imagine-video": (4, "720p", False),
}
MODELS.update(COMPAT_PROFILES)

MAX_JSON = 1024 * 1024


class VideoError(Exception):
    pass


class HTTPFailure(VideoError):
    def __init__(self, status):
        self.status = status
        super().__init__("http_" + str(status))


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def emit(**fields):
    print(json.dumps(fields, ensure_ascii=False), flush=True)


def normalize_origin(value):
    parsed = urllib.parse.urlsplit(value.rstrip("/"))
    if (parsed.scheme != "https" or parsed.hostname not in HOSTS or
            parsed.username or parsed.password or parsed.query or parsed.fragment or
            parsed.port not in (None, 443) or parsed.path not in ("", "/v1")):
        raise VideoError("Use a YuanHeng HTTPS base URL, optionally ending in /v1.")
    return "https://" + parsed.hostname


def task_id(value):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,160}", value):
        raise VideoError("Invalid or missing task ID; do not resubmit. Check server task logs.")
    return value


def load_state(path):
    if path.is_symlink():
        raise VideoError("Recovery file must not be a symlink.")
    with path.open("rb") as stream:
        data = stream.read(MAX_JSON + 1)
    if len(data) > MAX_JSON:
        raise VideoError("Recovery file is too large.")
    state = json.loads(data)
    if not isinstance(state, dict) or state.get("version") != 1:
        raise VideoError("Unrecognized recovery record.")
    normalize_origin(state["origin"])
    return state


def save_state(path, state, exclusive=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    data = json.dumps(state, ensure_ascii=False, indent=2).encode()
    if exclusive:
        try:
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError:
            raise VideoError("Recovery file already exists. Use --resume; do not submit again.") from None
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        return
    fd, temporary = tempfile.mkstemp(prefix=".video-state-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def request_json(origin, suffix, key, payload=None, timeout=30):
    data = None if payload is None else json.dumps(payload).encode()
    request = urllib.request.Request(origin + suffix, data=data, headers={
        "Authorization": "Bearer " + key, "Content-Type": "application/json",
        "Accept": "application/json", "User-Agent": "yuanheng-video-skill/1.0",
    })
    opener = urllib.request.build_opener(NoRedirect())
    try:
        with opener.open(request, timeout=timeout) as response:
            raw = response.read(MAX_JSON + 1)
    except urllib.error.HTTPError as exc:
        status = exc.code
        exc.close()
        raise HTTPFailure(status) from None
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        cause = getattr(exc, "reason", exc)
        # Do not echo proxy URLs, headers, keys, or a server-controlled response.
        raise VideoError("connection_failed:" + type(cause).__name__) from None
    if len(raw) > MAX_JSON:
        raise VideoError("Response exceeds the JSON limit.")
    try:
        body = json.loads(raw)
    except (ValueError, UnicodeError):
        raise VideoError("Invalid JSON response.") from None
    if not isinstance(body, dict):
        raise VideoError("Expected a JSON object response.")
    return body


def reference_data_uri(filename, max_bytes=20 * 1024 * 1024, allow_webp=False, budget=None):
    try:
        with Path(filename).expanduser().open("rb") as stream:
            raw = stream.read(max_bytes + 1)
    except OSError:
        raise VideoError("Cannot read reference image.") from None
    if len(raw) > max_bytes:
        raise VideoError("Reference image exceeds the model file-size limit.")
    if budget is not None:
        budget[0] -= len(raw)
        if budget[0] < 0:
            raise VideoError("Muse reference images exceed 24 MB in total.")
    if raw.startswith(b"\x89PNG\r\n\x1a\n"):
        mime = "image/png"
    elif raw.startswith(b"\xff\xd8\xff"):
        mime = "image/jpeg"
    elif allow_webp and raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
        mime = "image/webp"
    else:
        raise VideoError("Reference must be PNG/JPEG, or WebP for Muse.")
    return "data:" + mime + ";base64," + base64.b64encode(raw).decode("ascii")


def payload_for(args):
    if args.model not in MODELS:
        raise VideoError("Unsupported video model; use a verified profile.")
    if not args.prompt or not args.prompt.strip():
        raise VideoError("A non-empty prompt is required.")
    if args.images and args.model not in {"muse-video", SEEDANCE_MODEL}:
        raise VideoError("Multiple references are supported for Muse and Seedance.")
    if args.image and args.images:
        raise VideoError("Use either --image or --images, not both.")
    profile = COMPAT_PROFILES.get(args.model)
    args.duration = args.duration if args.duration is not None else (profile[0] if profile else 1)
    args.resolution = args.resolution or (profile[1] if profile else "480p")
    if args.model == SEEDANCE_MODEL:
        if args.duration <= 0:
            raise VideoError("Duration must be a positive integer.")
        payload = {"model": args.model, "prompt": args.prompt.strip(), "seconds": str(args.duration),
                   "resolution": args.resolution,
                   "metadata": {"ratio": args.aspect_ratio, "generate_audio": True, "watermark": False}}
        refs = args.images or ([args.image] if args.image else [])
        if refs:
            payload["images"] = [reference_data_uri(f, allow_webp=True) for f in refs]
        return payload
    if profile:
        if args.model == "muse-video":
            if not 4 <= args.duration <= 180 or args.resolution != "720p":
                raise VideoError("Muse accepts integer durations 4-180 seconds at 720p; 1080p output is not verified.")
        elif args.duration != profile[0] or args.resolution != profile[1]:
            raise VideoError("This model profile only supports the verified duration and resolution.")
        if args.model != "muse-video" and bool(args.image) != profile[2]:
            raise VideoError("This profile requires --image." if profile[2] else "This profile does not accept reference images.")
        if args.aspect_ratio not in {"16:9", "9:16"}:
            raise VideoError("This profile requires 16:9 or 9:16.")
        width, height = (1920, 1080) if args.resolution == "1080p" else (1280, 720)
        if args.aspect_ratio == "9:16":
            width, height = height, width
        payload = {"model": args.model, "prompt": args.prompt.strip(), "seconds": str(args.duration), "size": f"{width}x{height}"}
        if args.model == "muse-video":
            if len(args.prompt) > 4000:
                raise VideoError("Muse prompt exceeds 4000 characters.")
            refs = args.images or ([args.image] if args.image else [])
            if len(refs) > 4:
                raise VideoError("Muse accepts at most 4 reference images.")
            budget = [24_000_000]
            encoded = [reference_data_uri(f, 10_000_000, True, budget) for f in refs]
            if args.images:
                payload["images"] = encoded
            elif encoded:
                payload["input_reference"] = encoded[0]
        elif args.image:
            payload["input_reference"] = reference_data_uri(args.image)
        return payload
    if args.resolution == "1080p" and args.model != "grok-imagine-video-1.5":
        raise VideoError("1080p requires grok-imagine-video-1.5.")
    if not 1 <= args.duration <= 15:
        raise VideoError("Duration must be between 1 and 15 seconds; provider limits still apply.")
    payload = {"model": args.model, "prompt": args.prompt.strip(), "duration": args.duration,
               "aspect_ratio": args.aspect_ratio, "resolution": args.resolution}
    if args.image:
        payload["image"] = {"url": reference_data_uri(args.image)}
    return payload


def inspect_mp4(path):
    """Read bounded container metadata, not the full video into memory."""
    size = path.stat().st_size
    result = {"audio_tracks": 0, "bytes": size}
    boxes_seen = [0]
    with path.open("rb") as stream:
        def boxes(start, end):
            pos = start
            while pos + 8 <= end:
                boxes_seen[0] += 1
                if boxes_seen[0] > 10000:
                    raise VideoError("MP4 contains too many boxes.")
                stream.seek(pos)
                head = stream.read(8)
                length, kind = struct.unpack(">I4s", head)
                header = 8
                if length == 1:
                    extra = stream.read(8)
                    if len(extra) != 8:
                        raise VideoError("Truncated MP4 box.")
                    length = struct.unpack(">Q", extra)[0]
                    header = 16
                elif length == 0:
                    length = end - pos
                if length < header or pos + length > end:
                    raise VideoError("Invalid or truncated MP4 box.")
                yield kind, pos + header, pos + length
                pos += length
            if pos != end:
                raise VideoError("Truncated MP4 box header.")

        def prefix(start, end, count=128):
            stream.seek(start)
            return stream.read(min(count, end - start))

        def duration(data):
            version = data[0] if data else -1
            if version == 0 and len(data) >= 20:
                scale, ticks = struct.unpack(">II", data[12:20])
            elif version == 1 and len(data) >= 32:
                scale = struct.unpack(">I", data[20:24])[0]
                ticks = struct.unpack(">Q", data[24:32])[0]
            else:
                raise VideoError("Invalid MP4 duration metadata.")
            if not scale or ticks <= 0:
                raise VideoError("Invalid MP4 timescale or duration.")
            return ticks / scale

        has_ftyp = False
        for kind, start, end in boxes(0, size):
            if kind == b"ftyp":
                has_ftyp = True
            if kind != b"moov":
                continue
            for child, a, b in boxes(start, end):
                if child == b"mvhd":
                    result["duration_seconds"] = duration(prefix(a, b))
                if child != b"trak":
                    continue
                track = {}
                for field, c, d in boxes(a, b):
                    if field == b"tkhd":
                        raw = prefix(c, d)
                        offset = 88 if raw and raw[0] == 1 else 76
                        if len(raw) >= offset + 8:
                            w, h = struct.unpack(">II", raw[offset:offset+8])
                            track.update(width=w / 65536, height=h / 65536)
                    if field == b"mdia":
                        for sub, e, f in boxes(c, d):
                            if sub == b"hdlr":
                                raw = prefix(e, f)
                                track["handler"] = raw[8:12]
                if track.get("handler") == b"soun":
                    result["audio_tracks"] += 1
                if track.get("handler") == b"vide" and track.get("width", 0) > 0 and track.get("height", 0) > 0:
                    result.update(width=track["width"], height=track["height"])
        if not has_ftyp or not result.get("duration_seconds") or not result.get("width"):
            raise VideoError("Downloaded file lacks valid MP4 video metadata.")
    return result


def download_artifact(args, state, key, opener=None):
    if not args.out:
        return 0
    target = Path(args.out).expanduser()
    if target.exists() or target.is_symlink():
        raise VideoError("Output already exists; choose a new path. No generation was submitted.")
    target.parent.mkdir(parents=True, exist_ok=True)
    origin = normalize_origin(state["origin"])
    url = origin + "/v1/videos/" + task_id(state["task_id"]) + "/content"
    request = urllib.request.Request(url, headers={"Authorization": "Bearer " + key,
        "Accept": "video/mp4", "User-Agent": "yuanheng-video-skill/1.1"})
    fd, temporary = tempfile.mkstemp(prefix=".video-download-" + str(os.getpid()) + "-", dir=target.parent)
    deadline = time.monotonic() + args.download_timeout
    try:
        opener = opener or urllib.request.build_opener(NoRedirect())
        with os.fdopen(fd, "wb") as output:
            with opener.open(request, timeout=args.download_timeout) as response:
                if response.status != 200 or response.headers.get_content_type() != "video/mp4":
                    raise VideoError("Content response is not a successful MP4 download.")
                count = 0
                while True:
                    if time.monotonic() >= deadline:
                        raise VideoError("Download timed out; retry only with --download-only.")
                    chunk = response.read(65536)
                    if not chunk:
                        break
                    count += len(chunk)
                    if count > 512 * 1024 * 1024:
                        raise VideoError("Download exceeds 512 MiB; task preserved.")
                    output.write(chunk)
                length = response.headers.get("Content-Length")
                if length is not None and int(length) != count:
                    raise VideoError("Truncated video download; task preserved.")
                output.flush()
                os.fsync(output.fileno())
        media = inspect_mp4(Path(temporary))
        # Hard-link publication is atomic and never overwrites an existing file.
        os.link(temporary, target)
        emit(phase="delivered", task_id=state["task_id"], output_file=str(target), media=media,
             requested_duration=state.get("duration"),
             visual_verification_required=True)
        return 0
    except urllib.error.HTTPError as exc:
        raise VideoError("Content HTTP " + str(exc.code) + "; retry only with --download-only.") from None
    except (urllib.error.URLError, TimeoutError, OSError, ValueError):
        raise VideoError("Content download or save failed; keep the task and retry with --download-only.") from None
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def run(args, request=request_json, clock=time.monotonic, sleep=time.sleep):
    path = Path(args.state).expanduser()
    if args.out and (Path(args.out).expanduser().exists() or Path(args.out).expanduser().is_symlink()):
        raise VideoError("Output already exists; choose a new path before submitting.")
    if args.download_only and not args.out:
        raise VideoError("--download-only requires --out.")
    if args.resume or args.download_only:
        state = load_state(path)
        origin = normalize_origin(state["origin"])
        if args.base_url and normalize_origin(args.base_url) != origin:
            raise VideoError("Resume must use the original API origin.")
        identifier = task_id(state.get("task_id"))
    else:
        origin = normalize_origin(args.base_url or "https://meta-api.com")
        payload = payload_for(args)
        if args.model == "muse-video":
            emit(warning="muse_actual_output_may_differ", requested_duration=args.duration,
                 requested_resolution=args.resolution,
                 detail="Supplier may normalize duration. Verify the media; task seconds/size are request echoes, not output proof.")
        state = {"version": 1, "origin": origin, "model": args.model,
                 "phase": "submission_unknown", "duration": args.duration,
                 "resolution": args.resolution, "aspect_ratio": args.aspect_ratio}
    if args.dry_run:
        emit(mode="download" if args.download_only else ("resume" if args.resume else "generate"), origin=origin,
             model=state["model"], state_file=str(path), network_requests=0,
             **({"task_id": identifier} if (args.resume or args.download_only) else {"parameters": {k: ("[local reference image]" if k in {"input_reference", "image", "images"} else v) for k, v in payload.items()}}))
        return 0
    key = os.environ.get("META_API_KEY", "").strip()
    if not key or len(key) > 8192 or any(not 33 <= ord(c) <= 126 for c in key):
        raise VideoError("Set META_API_KEY to the user's YuanHeng API key.")
    fingerprint = hashlib.sha256(key.encode()).hexdigest()
    if (args.resume or args.download_only) and state.get("credential_fingerprint") != fingerprint:
        raise VideoError("Resume requires the original credential. No alternate key will be tried.")
    if args.download_only:
        if state.get("phase") != "completed":
            raise VideoError("Task is not recorded as completed; use --resume first.")
        return download_artifact(args, state, key)
    deadline = clock() + args.wait
    if not args.resume:
        state["credential_fingerprint"] = fingerprint
        save_state(path, state, exclusive=True)
        emit(phase="submitting", state_file=str(path), paid_submissions=1)
        try:
            response = request(origin, "/v1/videos", key, payload=payload,
                               timeout=min(600, args.wait))
            identifier = task_id(response.get("id"))
        except VideoError:
            emit(phase="submission_unknown", state_file=str(path),
                 action="Check task and usage logs before any new submission.")
            raise
        # Emit before disk I/O so an ID remains visible even if persistence fails.
        emit(phase="accepted", task_id=identifier)
        state.update(task_id=identifier, phase="queued")
        save_state(path, state)
    interval = 2
    consecutive_unknown = 0
    while clock() < deadline:
        try:
            response = request(origin, "/v1/videos/" + identifier, key,
                               timeout=max(0.1, min(30, deadline - clock())))
        except HTTPFailure as exc:
            if exc.status != 429 and not 500 <= exc.status <= 599:
                raise
            emit(phase="query_retry", task_id=identifier, error=str(exc))
        except VideoError as exc:
            emit(phase="query_retry", task_id=identifier, error=str(exc))
        else:
            if response.get("id") != identifier:
                raise VideoError("Task response ID does not match the requested task.")
            status = response.get("status")
            if status == "unknown":
                consecutive_unknown += 1
                if consecutive_unknown > 3:
                    raise VideoError("Task status remained unknown; keep the task ID and inspect logs.")
                emit(phase="query_retry", task_id=identifier, error="initial_status_unknown",
                     attempt=consecutive_unknown)
                sleep(min(3, max(0, deadline - clock())))
                continue
            consecutive_unknown = 0
            if status not in {"queued", "in_progress", "completed", "failed"}:
                raise VideoError("Unknown task status; keep the task ID and inspect logs.")
            if status == "completed":
                # Delivery always uses the original gateway and credential. Never
                # expose or follow upstream URLs, even on an older server response.
                url = origin + "/v1/videos/" + identifier + "/content"
                state.update(phase="completed", url=url, authenticated_content=True)
                save_state(path, state)
                emit(phase="completed", task_id=identifier, content_url=url,
                     requires_authorization=True, state_file=str(path))
                return download_artifact(args, state, key)
            state["phase"] = status
            save_state(path, state)
            emit(phase=status, task_id=identifier)
            if status == "failed":
                raise VideoError("Video generation failed. Check task/usage logs; no resubmission was made.")
        remaining = deadline - clock()
        if remaining <= 0:
            break
        sleep(min(interval, remaining))
        interval = min(interval * 1.5, 15)
    emit(phase="pending", task_id=identifier, state_file=str(path), action="Use --resume to query this task.")
    return 2


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--base-url", help="YuanHeng API origin, optional /v1 suffix")
    p.add_argument("--model", default=MODEL)
    p.add_argument("--prompt")
    p.add_argument("--image", help="Local first frame: PNG/JPEG; Muse/Seedance also accept WebP")
    p.add_argument("--images", nargs="+", help="Ordered local PNG/JPEG/WebP references; Muse accepts 1-4")
    p.add_argument("--duration", type=int, default=None)
    p.add_argument("--aspect-ratio", choices=["16:9", "9:16", "1:1"], default="16:9")
    p.add_argument("--resolution", choices=["480p", "720p", "1080p"], default=None)
    p.add_argument("--state", default="output/video/task.json")
    p.add_argument("--resume", action="store_true")
    p.add_argument("--out", help="Stream completed MP4 to a new local path and inspect media metadata")
    p.add_argument("--download-only", action="store_true", help="GET content from completed state; never submit or poll")
    p.add_argument("--download-timeout", type=int, default=900, help="Download budget in seconds (1-3600)")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--wait", type=int, default=None, help="Wait 1-3600 seconds; default 1800 for Muse over 30s, otherwise 420")
    p.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    return p


def effective_wait(args):
    if args.wait is not None:
        return args.wait
    model, duration = args.model, args.duration or 0
    if args.resume or args.download_only:
        state = load_state(Path(args.state).expanduser())
        model, duration = state.get("model"), state.get("duration", 0)
    return 1800 if model == "muse-video" and duration > 30 else 420


def main():
    args = parser().parse_args()
    try:
        args.wait = effective_wait(args)
    except (VideoError, OSError, ValueError, KeyError, TypeError):
        emit(error="Cannot read recovery state for wait selection.", state_file=args.state)
        return 1
    if not 1 <= args.download_timeout <= 3600:
        emit(error="--download-timeout must be between 1 and 3600")
        return 1
    if not 1 <= args.wait <= 3600:
        emit(error="--wait must be between 1 and 3600 seconds")
        return 1
    if not args.worker and not args.dry_run:
        def interrupted(signum, frame):
            raise KeyboardInterrupt
        signal.signal(signal.SIGTERM, interrupted)
        child = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), *sys.argv[1:], "--worker"])
        try:
            return child.wait(timeout=(0 if args.download_only else args.wait) + (args.download_timeout if args.out else 0) + 5)
        except (subprocess.TimeoutExpired, KeyboardInterrupt):
            emit(phase="interrupted", state_file=args.state,
                 action="Do not resubmit. Resume if the record contains a task ID; otherwise check server logs.")
            return 2
        finally:
            if child.poll() is None:
                child.terminate()
                try:
                    child.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    child.kill()
                    child.wait()
            if args.out and child.poll() is not None:
                for partial in Path(args.out).expanduser().parent.glob(".video-download-" + str(child.pid) + "-*"):
                    try:
                        partial.unlink()
                    except OSError:
                        emit(download_temp_cleanup="unverified")
            emit(owned_worker_exited=True, residual_owned_workers=0)
    try:
        return run(args)
    except (VideoError, OSError, ValueError, KeyError, TypeError) as exc:
        message = str(exc) if isinstance(exc, VideoError) else "Local recovery/validation error: " + type(exc).__name__
        emit(error=message, state_file=args.state)
        return 1


if __name__ == "__main__":
    sys.exit(main())
